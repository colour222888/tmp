package com.cxyzy.demo

data class Task(var id: Int, var name: String?)