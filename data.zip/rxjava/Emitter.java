package com.example.testdemo.rxjava;

/**
 * 定义了发送消息的api
 */
public interface Emitter<T> {
    //发送消息
    void onNext(T t);
    //发送异常
    void onError(Throwable e);
    //发送完成的信号
    void onComplete();
}
