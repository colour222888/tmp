package com.example.testdemo.rxjava;

/**
 * 抽象被观察者
 */
public interface ObservableSource <T>{
    //notify() 将给定的observer订阅功能定义处理
    void subscribe(Observer<T> observer);
}
