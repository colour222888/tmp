package com.example.testdemo.rxjava;

public abstract class Pizza {
    protected String name;
    public String getName(){
        return this.name;
    }
    public abstract double getPrice();
}
