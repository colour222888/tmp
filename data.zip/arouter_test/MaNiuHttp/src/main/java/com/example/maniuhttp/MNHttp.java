package com.example.maniuhttp;

public class MNHttp {
    public static <T, M> void sendJsonHttpRequest(String url, T requestData, Class<M> responseClass, IJsonDataListener listener) {
        IHttpRequest httpRequest = new JsonHttpRequest();
        CallBackListener callBackListener = new JsonCallbackListener<>(responseClass, listener);
        HttpTask ht = new HttpTask(url, requestData, httpRequest, callBackListener);
        ThreadPoolManager.getInstance().addTask(ht);
    }
}
