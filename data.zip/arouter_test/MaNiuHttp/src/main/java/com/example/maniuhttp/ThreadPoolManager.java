package com.example.maniuhttp;

import android.util.Log;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class ThreadPoolManager {
    //创建队列
    private final LinkedBlockingQueue<Runnable> mQueue = new LinkedBlockingQueue<>();

    private static final ThreadPoolManager threadPoolManager = new ThreadPoolManager();

    public static ThreadPoolManager getInstance() {
        return threadPoolManager;
    }

    public void addTask(Runnable runnable) {
        if (runnable != null) {
            try {
                mQueue.put(runnable);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    //创建线程池
    private final ThreadPoolExecutor mThreadPoolExecutor;

    private ThreadPoolManager() {
        mThreadPoolExecutor = new ThreadPoolExecutor(3, 10, 60, TimeUnit.SECONDS, new ArrayBlockingQueue<>(4),
                (r, executor) -> {
                    //可以按照自己的方式进行处理
                    addTask(r);
                });
        //创建“服务员”线程
        Runnable coreThread = new Runnable() {
            Runnable runnable = null;

            @Override
            public void run() {
                try {
                    while (true) {
                        Log.e("ycj","mQueue.take() start");
                        runnable = mQueue.take();
                        Log.e("ycj","mQueue.take() end");
                        mThreadPoolExecutor.execute(runnable);
                        Log.e("ycj","mThreadPoolExecutor.execute(runnable)");
                    }
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        };
        mThreadPoolExecutor.execute(coreThread);
    }
}
