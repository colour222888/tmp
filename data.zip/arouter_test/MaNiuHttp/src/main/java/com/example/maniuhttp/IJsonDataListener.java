package com.example.maniuhttp;

public interface IJsonDataListener<T> {
    void onSuccess(T m);
    void onFailure();
}
