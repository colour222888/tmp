package com.example.maniuhttp;

import com.alibaba.fastjson.JSON;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class JsonCallbackListener<T> implements CallBackListener{
    private Class<T> responseClass;
    private IJsonDataListener jsonDataListener;
    public JsonCallbackListener(Class<T> responseClass, IJsonDataListener jsonDataListener){
        this.responseClass = responseClass;
        this.jsonDataListener = jsonDataListener;
    }
    @Override
    public void onSuccess(InputStream inputStream) {
//将服务器返回的流转换成对应的对象
        String response = getContent(inputStream);
        T clazz = JSON.parseObject(response,responseClass);
        jsonDataListener.onSuccess(clazz);
    }

    private String getContent(InputStream inputStream) {
        BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
        StringBuilder sb = new StringBuilder();
        String line = null;
        try {
            while ((line = reader.readLine()) != null){
                sb.append(line + "\n");
            }
        }catch (IOException e){
            System.out.println("errors:"+e.toString());
        }finally {
            try {
                inputStream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
       return sb.toString();
    }

    @Override
    public void onFailure() {

    }
}
