package com.example.servertest

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    var name: String? = null
    protected var mDes: String? = null
    var mId: String? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
//        Log.e("ycj","processName:${AndroidUtil.getProcessName(this)}")
//        Log.e("ycj","onStartCommand pid:"+android.os.Binder.getCallingPid() +"; "+android.os.Binder.getCallingUid())
    }

    override fun onDestroy() {
        Log.e("ycj","MainActivity onDestroy")
        super.onDestroy()
    }

    fun startServer(view: View?) {
        val intent = Intent(this, Myserver::class.java)
        intent.putExtra("ycj", "hello server")
        startService(intent)
    }

    fun stopServer(view: View?) {
        stopService(Intent(this, Myserver::class.java))
    }

    private fun measure(a: Int, b: String): String {
        return a.toString() + b
    }

    protected fun add(i: Int, j: Int): Int {
        return i + j
    }

}