package com.example.servertest

import android.app.Activity
import android.os.Bundle
import android.util.Log
import android.view.View

class KTTest : Activity(), View.OnClickListener {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val view1 = View(this)
        view1.setOnClickListener(this)
        val view2 = View(this)
        view2.setOnClickListener { v ->
            Log.e(TAG, "11111111$v")
            Log.e(TAG, "22222222")
        }
    }

    override fun onClick(v: View) {
        Log.e(TAG, "hello$v")
        Log.e(TAG, "ycj")
    }

    internal interface Download {
        fun upload(url: String?): Boolean
    }

    companion object {
        private const val TAG = "ycj"
        var Type = 1
    }
}