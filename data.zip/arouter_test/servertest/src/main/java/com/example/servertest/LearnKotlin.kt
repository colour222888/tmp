package com.example.servertest

fun main() {
    println("hello kotlin")
}
