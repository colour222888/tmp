package com.example.networklib;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Query;

public interface ApiService {
    //https://v.juhe.cn/historyWeather/citys?province_id=2&key=bb52107206585ab074f5e59a8c73875b
    //http://jmgoapp.holatek.cn/user/auth/loginPwd
    String WEATHER_URL = "https://v.juhe.cn/";
    String LOGIN_URL = "http://jmgoapp.holatek.cn/";

    @GET("historyWeather/citys")
    Call<WeatherBean> requestWeather(@Query("province_id")String province_id,@Query("key")String key);

    @POST("http://jmgoapp.holatek.cn/user/auth/loginPwd")
    Call<LoginResultBean> userLogin(@Body LoginUserBean loginUserBean);//@body即非表单请求体，被@body注解的loginUserBean将会被转换成json发送到服务器
}
