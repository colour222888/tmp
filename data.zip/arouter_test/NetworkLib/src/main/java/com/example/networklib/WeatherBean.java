package com.example.networklib;

public class WeatherBean {
    //""resultcode":"112","reason"":"112","reason"
    String resultcode;
    String reason;

    public String getResultcode() {
        return resultcode;
    }

    public void setResultcode(String resultcode) {
        this.resultcode = resultcode;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    @Override
    public String toString() {
        return "WeatherBean{" +
                "resultcode='" + resultcode + '\'' +
                ", reason='" + reason + '\'' +
                '}';
    }
}
