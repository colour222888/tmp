package com.example.networklib;

import com.google.gson.Gson;

import java.io.IOException;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class Main {
    public static void main(String[] args) {
//        new Thread(() -> retrofitGetTest()).start();
        new Thread(() -> retrofitPostTest()).start();

//        okhttpGetTest();
//        okhttpPostTest();
    }

    public static void retrofitGetTest() {
        Retrofit retrofit = new Retrofit.Builder().baseUrl(ApiService.WEATHER_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        ApiService apiService = retrofit.create(ApiService.class);
        Call<WeatherBean> weatherBeanCall = apiService.requestWeather("2", "bb52107206585ab074f5e59a8c73875b");
//        try {
//            Response<WeatherBean> executeRespon = weatherBeanCall.execute();
//            if (executeRespon != null){
//                System.out.println(executeRespon.body());
//            }
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
        weatherBeanCall.enqueue(new Callback<WeatherBean>() {
            @Override
            public void onResponse(Call<WeatherBean> call, Response<WeatherBean> response) {
                System.out.println(response.body());
            }

            @Override
            public void onFailure(Call<WeatherBean> call, Throwable t) {

            }
        });
    }

    public static void retrofitPostTest() {
        String account = "13726238721";
        String pwd = "hl222888";
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(ApiService.LOGIN_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        ApiService apiService = retrofit.create(ApiService.class);
        Call<LoginResultBean> loginUserBeanCall = apiService.userLogin(new LoginUserBean(account, pwd));
        loginUserBeanCall.enqueue(new Callback<LoginResultBean>() {
            @Override
            public void onResponse(Call<LoginResultBean> call, Response<LoginResultBean> response) {
                System.out.println("retrofitPostTest response.body:"+response.body());
            }

            @Override
            public void onFailure(Call<LoginResultBean> call, Throwable t) {
                System.out.println("retrofitPostTest onFailure:"+t.getMessage());
            }
        });
    }

    public static void okhttpGetTest() {
        Request request = new Request.Builder()
                .url("https://v.juhe.cn/historyWeather/citys?province_id=2&key=bb52107206585ab074f5e59a8c73875b")
                .build();
        OkHttpClient client = new OkHttpClient();
        okhttp3.Call call = client.newCall(request);
        try {
            okhttp3.Response response = call.execute();
            System.out.println("okhttpGet response.body:" + response.body().string());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void okhttpPostTest() {
        /**
         * loginUser.setAccount(phone);
         *             loginUser.setPassword(passWord);
         *
         *             RequestBody body = FormBody.create(MediaType.parse("application/json;charset=UTF-8"), GsonUtils.toJson(loginUser));
         *
         *             public static String HOST_APP_LOGINPWD = HOST_USER + "/auth/loginPwd";  //用户账号密码登录接口
         *             "http://47.113.191.0:8033/user";
         *             "http://jmgoapp.holatek.cn/user";
         */
        String account = "13726238721";
        String pwd = "hl222888";
        OkHttpClient okHttpClient = new OkHttpClient();
        RequestBody body = RequestBody.create(MediaType.parse("application/json;charset=UTF-8"), new Gson().toJson(new LoginUserBean(account, pwd)));
        Request request = new Request.Builder()
                .url("https://jmgoapp.holatek.cn/user/auth/loginPwd")
                .post(body)
                .build();
        okhttp3.Call call = okHttpClient.newCall(request);
        try {
            okhttp3.Response response = call.execute();
            System.out.println("okhttpPost response.body:" + response.body().string());

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
