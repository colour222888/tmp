package com.example.annotation_compiler;

import com.example.annotation.BindPath;
import com.google.auto.service.AutoService;

import java.io.IOException;
import java.io.Writer;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import javax.annotation.processing.AbstractProcessor;
import javax.annotation.processing.Filer;
import javax.annotation.processing.ProcessingEnvironment;
import javax.annotation.processing.Processor;
import javax.annotation.processing.RoundEnvironment;
import javax.lang.model.SourceVersion;
import javax.lang.model.element.Element;
import javax.lang.model.element.Name;
import javax.lang.model.element.TypeElement;
import javax.tools.JavaFileObject;

import static com.example.annotation.ConfigString.CLASS_NAME_PRE;
import static com.example.annotation.ConfigString.CLASS_PACKAGE_NAME;

/**
 * 替我们生成工具类的代码
 */
@AutoService(Processor.class)
public class AnnotationCompiler extends AbstractProcessor {
    private Filer filer;

    @Override
    public synchronized void init(ProcessingEnvironment processingEnv) {
        super.init(processingEnv);
        filer = processingEnv.getFiler();
    }


    @Override
    public SourceVersion getSupportedSourceVersion() {
        return processingEnv.getSourceVersion();
    }


    @Override
    public Set<String> getSupportedAnnotationTypes() {
        Set<String> types = new HashSet<>();
        types.add(BindPath.class.getCanonicalName());
        return types;
    }

    @Override
    public boolean process(Set<? extends TypeElement> annotations, RoundEnvironment roundEnv) {
        //获取当前模块用到了bindPath的节点
        //TypeElement        类节点
        //ExecutableElement  方法节点
        //VariableElement    成员变量节点
        Set<? extends Element> elementsAnnotatedWith = roundEnv.getElementsAnnotatedWith(BindPath.class);
        Map<String, String> map = new HashMap<>();
        for (Element element : elementsAnnotatedWith) {
            TypeElement typeElement = (TypeElement) element;
            //获取到activity上面的BindPath的注解
            BindPath annotation = typeElement.getAnnotation(BindPath.class);
            String key = annotation.value();
            //获取到包名加类名
            Name qualifiedName = typeElement.getQualifiedName();
            map.put(key, qualifiedName + ".class");
        }


        //写文件
        if (map.size() > 0) {
            Writer writer = null;
            //需要生成文件的类名
            String activityName = CLASS_NAME_PRE + System.currentTimeMillis();
            //生成一个java文件
            try {
                //牢记是用createSourceFile，而不是createClassFile。不然会报错：
                JavaFileObject sourceFile = filer.createSourceFile(CLASS_PACKAGE_NAME + "." + activityName);
                writer = sourceFile.openWriter();
                StringBuffer stringBuffer = new StringBuffer();
                stringBuffer.append("package " + CLASS_PACKAGE_NAME + ";\n");
                stringBuffer.append("import com.example.arouter.ARouter;\n" +
                        "import com.example.arouter.IRouter;\n" +
                        "\n" +
                        "public class " + activityName + " implements IRouter {\n" +
                        "    @Override\n" +
                        "    public void putActivity() {\n");
                Iterator<String> iterator = map.keySet().iterator();
                while (iterator.hasNext()) {
                    String key = iterator.next();
                    String className = map.get(key);
                    stringBuffer.append("ARouter.getInstance().addActivity(\"" + key + "\"," +
                            className + ");\n");
                }
                stringBuffer.append("\n}\n}");
                writer.write(stringBuffer.toString());
            } catch (IOException e) {
                System.out.println("e:" + e.getMessage());
                e.printStackTrace();
            } finally {
                if (writer != null) {
                    try {
                        writer.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }

        return false;
    }
}
