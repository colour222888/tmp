package com.example.rxjava;

public abstract class Pizza {
    protected String name;

    public String getName() {
        return this.name;
    }

    public abstract double getPrice();

    public static void main(String[] args) {
        System.out.println("*************333");
        testRxjava();
//        testDecorator();
    }


    private static void testRxjava() {
        Observable<String> stringObservable = Observable.create(new ObservableOnSubscribe<String>() {
            @Override
            public void subscribe(Emitter<String> emitter) {
                String msg = "hello rxjava";
                System.out.println("emitter 发送：" + msg);
                emitter.onNext(msg);
            }
        });
        Observable map = stringObservable.map(new Function<String, String>() {
            @Override
            public String apply(String s) {
                System.out.println("this:" + this + "map1 收到：" + s);
                return s + " +map1";
            }
        });
        Observable map1 = map.map(new Function<String, String>() {
            @Override
            public String apply(String s) {
                System.out.println("this:" + this + "map2 收到：" + s);
                return s + " +map2";
            }
        });
        map1.subscribe(new Observer() {
            @Override
            public void onSubscribe() {

            }

            @Override
            public void onNext(Object o) {
                System.out.println("接收到消息：" + (String) o);
            }

            @Override
            public void onError(Throwable e) {

            }

            @Override
            public void onComplete() {

            }
        });

        System.out.println("map,map1:" + map + ";" + map1);
    }

    //测试装饰模式
    private static void testDecorator() {
        Decorator decorator = new PizzaA(new PizzaB(new BasePizza()));
        decorator.show();
    }
}
