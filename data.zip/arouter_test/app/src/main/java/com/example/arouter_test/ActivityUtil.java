package com.example.arouter_test;

import com.example.arouter.ARouter;
import com.example.arouter.IRouter;

public class ActivityUtil implements IRouter {
    @Override
    public void putActivity() {
        ARouter.getInstance().addActivity("worktest/radio_group", MainActivity.class);
    }
}
