package com.example.arouter_test;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModel;

import android.content.ComponentName;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.RadioButton;

import com.example.annotation.BindPath;
import com.example.maniuhttp.IJsonDataListener;
import com.example.maniuhttp.MNHttp;
import com.example.maniuhttp.WeatherBean;
import com.example.networklib.Main;
import com.example.rxjava.Emitter;
import com.example.rxjava.Observable;
import com.example.rxjava.ObservableOnSubscribe;
import com.example.rxjava.Observer;

import java.lang.ref.WeakReference;

@BindPath("app/main")//
public class MainActivity extends AppCompatActivity implements Handler.Callback {
    ViewModel viewModel;

    private WeakReference<View> mWeakReferenceView;
    private RadioButton test_radiobtn;
    private Handler mHandler = new Handler() {
        @Override
        public void handleMessage(@NonNull Message msg) {
            switch (msg.what) {
                case 1:
                    Log.e("ycj", "handleMessage msg.what is ````````1");
                    break;
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        test_radiobtn = findViewById(R.id.test_radiobtn);
        test_radiobtn.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
            }
        });

//        sendRequest();

//        Log.e("ycj","mWeakReferenceView:"+ mWeakReferenceView);
//        mWeakReferenceView = new WeakReference<>(new View(this));
//        Log.e("ycj","mWeakReferenceView:"+ mWeakReferenceView);
//        Log.e("ycj","View:"+ mWeakReferenceView.get());


        startOtherAppService();

        //retrofit test
        retrofitTest();
    }

    public void testBtnOnclick(View view) {
        startOtherAppService();

        Log.e("ycj", "testBtnOnclick sendToTarget begiin");
//        mHandler.obtainMessage(1).sendToTarget();
        Message message = new Message();
        message.what = 1;
//        mHandler.sendMessage(message);
        mHandler.sendMessageDelayed(message, 0);
        for (int i = 0; i < 1000; i++) {
            Log.e("ycj", "---------------i:" + i);
        }
        Log.e("ycj", "testBtnOnclick sendToTarget end");
    }

    private void sendRequest() {
        String url = "https://v.juhe.cn/historyWeather/citys?province_id=2&key=bb52107206585ab074f5e59a8c73875b";
        MNHttp.sendJsonHttpRequest(url, null, WeatherBean.class, new IJsonDataListener<WeatherBean>() {
            @Override
            public void onSuccess(WeatherBean m) {
                Log.e("ycj", "m.toString:" + m.toString());
            }

            @Override
            public void onFailure() {

            }
        });
    }

    @Override
    public boolean handleMessage(@NonNull Message msg) {
        switch (msg.what) {
            case 1:
                Log.e("ycj", "handleMessage msg.what is 1");
                break;
        }
        return false;
    }

    private void test() {
        Observable.create(new ObservableOnSubscribe<String>() {
            @Override
            public void subscribe(Emitter<String> emitter) {
                emitter.onNext("hello Observable");
            }
        }).subscribe(new Observer() {
            @Override
            public void onSubscribe() {

            }

            @Override
            public void onNext(Object o) {

            }

            @Override
            public void onError(Throwable e) {

            }

            @Override
            public void onComplete() {

            }
        });
    }

    private void startOtherAppService() {
        Intent intent = new Intent();
        intent.setComponent(new ComponentName("com.example.servertest", "com.example.servertest.Myserver"));
        startService(intent);
    }

    private void retrofitTest() {
        Main.retrofitGetTest();
    }
}