package com.example.rxjava;

public class BasePizza extends Pizza{


    @Override
    public String getName() {
        this.name = "原味pizza";
        return this.name;
    }

    @Override
    public double getPrice() {
        return 50;
    }
}
