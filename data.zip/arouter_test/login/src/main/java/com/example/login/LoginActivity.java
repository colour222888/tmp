package com.example.login;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.example.annotation.BindPath;

@BindPath("login/loginActivity")
public class LoginActivity extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable @org.jetbrains.annotations.Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        TextView textView = new TextView(this.getApplicationContext());
        textView.setText("login activity");
        setContentView(textView);

        ImageView imageView = new ImageView(this);
        ImageView imageView2 = new ImageView(this);
        String url = "http://jmgoserver.qiniu.holatek.cn/L6aUYkvza5zM9Ll57dor0AXD.png";
        Glide.with(this).load(url).into(imageView);
        Glide.with(this).load(url).into(imageView2);
    }
}
