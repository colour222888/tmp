package com.example.annotation;

public class ConfigString {
    //需要生成文件的包名
    public static final String CLASS_PACKAGE_NAME = "com.arouter.auto.generate.code";  //类的包名
    public static final String CLASS_NAME_PRE = "Util";  //类名的前缀
}
