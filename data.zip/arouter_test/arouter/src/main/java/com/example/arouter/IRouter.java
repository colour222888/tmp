package com.example.arouter;

public interface IRouter {
    void putActivity();
}
