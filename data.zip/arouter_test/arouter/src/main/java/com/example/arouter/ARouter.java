package com.example.arouter;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import java.lang.reflect.AnnotatedElement;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import dalvik.system.DexFile;

public class ARouter {
    private static ARouter aRouter = new ARouter();
    private Map<String, Class<? extends Activity>> maps; //装载了所有的Activity的类对象
    private Context context;//上下文

    private ARouter() {
        maps = new HashMap<>();
    }

    public static ARouter getInstance() {
        return aRouter;
    }

    public void init(Context context) {
        this.context = context;
        List<String> classNames = getClassName("com.arouter.auto.generate.code");
        for (String className : classNames) {
            try {
                Class<?> aClass = Class.forName(className);
                //判断这个类是否是IRouter的子类
                if (IRouter.class.isAssignableFrom(aClass)){
                    //通过接口的引用指向子类的实例
                    IRouter iRouter = (IRouter) aClass.newInstance();
                    iRouter.putActivity();
                }
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InstantiationException e) {
                e.printStackTrace();
            }
        }
    }

    //获取packageName包下的说有类的类名
    private List<String> getClassName(String packageName) {
        //创建一个class对象的集合
        List<String> classList = new ArrayList<>();
        String path = null;
        try {
            //通过包管理器  获取到应用信息类然后获取到apk的完整路径
            path = context.getPackageManager().getApplicationInfo(context.getPackageName(), 0).sourceDir;
            //根据apk的完整路径获取到编译后的dex文件目录
            DexFile dexFile = new DexFile(path);
            //获取编译后的dex文件中的所有的class
            Enumeration entries = dexFile.entries();
            //然后进行遍历
            while(entries.hasMoreElements()){
                //通过遍历所有的class的包名
                String name = (String) entries.nextElement();
                if (name.contains(packageName)){//如果符合 就添加到集合中
                    classList.add(name);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return classList;
    }

    //将activity类对象添加进容器
    public void addActivity(String key, Class<? extends Activity> clazz) {
        if (key != null && clazz != null && !maps.containsKey(key)) {
            maps.put(key, clazz);
        }
    }

    public void jumpActivity(String key, Bundle bundle, Activity activity) {
        Class<? extends Activity> activityClass = maps.get(key);
        if (activityClass != null) {
            Intent intent = new Intent().setClass(context, activityClass);
            if (bundle != null) {
                intent.putExtras(bundle);
            }
            if (activity == null){
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK );
                context.startActivity(intent);
            }else {
                activity.startActivity(intent);
            }
        }
    }
}
