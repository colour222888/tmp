package com.qingmei2.androiddagger2.bean;

/**
 * Created by QingMei on 2017/7/31.
 * desc:
 */

public class Student {
}
