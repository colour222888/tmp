package com.qingmei2.androiddagger2.mvp.contract;

/**
 * Created by QingMei on 2017/8/16.
 * desc:
 */

public interface MainContract {

    public interface View {

    }

    public interface Presenter {

    }

    public interface Model {

    }
}
