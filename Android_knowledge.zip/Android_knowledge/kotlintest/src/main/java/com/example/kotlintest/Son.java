package com.example.kotlintest;

public class Son {

    public Son(String name) {

    }
}
