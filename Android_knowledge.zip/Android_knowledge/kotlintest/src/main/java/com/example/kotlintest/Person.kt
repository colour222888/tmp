package com.example.kotlintest

class Person {
    private lateinit var name: String
    val add = "shenzhen"
    var title = "dalao"

}