package com.example.kotlintest

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Message
import android.util.Log
import android.view.View
import android.view.Window

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        mWindow = window;
        mHand = object : Handler() {
            override fun handleMessage(msg: Message?) {
                super.handleMessage(msg)
            }
        }
    }

    lateinit var mHand: Handler;
    lateinit var mWindow: Window;

    fun onclick(view: View) {
        Thread(object : Runnable {
            override fun run() {
                Log.e("ycj", "tread run");
            }
        }).start();
    }

}
