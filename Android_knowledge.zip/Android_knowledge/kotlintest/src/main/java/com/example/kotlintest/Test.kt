package com.example.kotlintest


fun main(args: Array<String>) {
    "hello".say("hello!!")

    val list: List<String> = listOf("apple", "pear", "banana", "watermolon")
    /*
     //java 写法
     var result = ""
     for (fruit:String in list){
         if (fruit.length > result.length){
             result = fruit
         }
     }*/

    //kotlin
    val result1: String? = list.maxBy { it.length }

    /**
     * lambda:一小段可以作为参数传递的代码
     * {参数名1:参数类型,参数名2:参数类型->函数体}
     */
    val lambda = { fruit: String -> fruit.length }
    val result2: String? = list.maxBy(lambda)

    val result3: String? = list.maxBy({ fruit: String -> fruit.length })
    val result4: String? = list.maxBy() { fruit: String -> fruit.length }//最后一个参数为lamda表达式时可以把表达式移出括号外
    val result5: String? = list.maxBy { fruit: String -> fruit.length }//只有一个参数并且为lamda表达式时，可以把括号去掉
    val result6: String? = list.maxBy { fruit -> fruit.length }//lamda表达式有非常出色的类型推导机制，可以把类型去掉
    val result7: String? = list.maxBy { it.length }//lamda表达式只有一个参数时，可以参数缺掉，函数使用it替代


    println("result1:" + result1)
    println("result2:" + result2)
    println("result3:" + result3)
    println("result4:" + result4)
    println("result5:" + result5)
    println("result6:" + result6)
    println("result7:" + result7)

    val num1 = 1;
    val num2 = 2
    num1AndNum2(num1, num2, ::minus)
    num1AndNum2(num1, num2, ::plus)
    //匿名函数形式
    num1AndNum2(num1, num2, fun(num1: Int, num2: Int): Int {
        return num1 + num2
    })
    //lamda表达式
    num1AndNum2(num1, num2) { a, b ->
        a + b
    }

}

//实现list.maxBy功能
fun <T, R : Comparable<R>> List<T>.findMax(block: (T) -> R): T? {
    if (isEmpty()) return null
    var maxElement: T = get(0);
    var maxValue: R = block(maxElement)
    for (element: T in this) {
        val value: R = block(element)
        if (value > maxValue) {
            maxElement = element
            maxValue = value
        }
    }
    return maxElement
}

//给String类添加扩展函数
fun String.say(str: String) {
    println("say:" + str);
}

fun String.capitalEnd(): String {
    val charArray: CharArray = this.toCharArray()
    charArray[length - 1] = charArray[length - 1].toUpperCase()
    return String(charArray)
}

//operation是函数类型
fun num1AndNum2(num1: Int, num2: Int, operation: (Int, Int) -> Int): Int {
    return operation(num1, num2);
}

fun minus(num1: Int, num2: Int): Int {
    return num1 - num2
}

fun plus(num1: Int, num2: Int): Int {
    return num1 + num2
}