package com.example.kotlintest

fun say(str: String): String {
    val num = "0";
    var name = "ken"
    println(str)
    return str
}