package com.example.replugin_host;

import com.qihoo360.replugin.RePluginApplication;

public class MyApplication extends RePluginApplication {
}
