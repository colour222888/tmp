package com.lihang.dagger2stu.study.kstudy.activitysingleton;


/**
 * Created by leo
 * on 2019/9/3.
 */
public class Children {

    public Children() {

    }
}
