package com.lihang.dagger2stu.study.astudy;

import javax.inject.Inject;

/**
 * Created by leo
 * on 2019/8/29.
 */

public class Person {

    @Inject
    public Person() {

    }

}
