package com.lihang.dagger2stu.study.bstudy;

/**
 * Created by leo
 * on 2019/8/29.
 */
public class Human {
    public Human() {

    }

}
