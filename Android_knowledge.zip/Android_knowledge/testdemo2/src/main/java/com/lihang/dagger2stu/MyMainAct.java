package com.lihang.dagger2stu;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.TextPaint;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JsResult;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MyMainAct extends Activity {
    View mTv;
    WebView mWebView;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout);

//        initWebView();

//        LinearLayout ll;
//        WindowManagerGlobal mGlobal = WindowManagerGlobal.getInstance();

//        mTv = findViewById(R.id.id_tv);
//        TextView t;
//
//        MyScrollView myScrollView = new MyScrollView(this);
//
//        setContentView(myScrollView);
    }
/*

    private void initWebView(){
        mWebView = findViewById(R.id.id_webview);

        WebSettings webSettings = mWebView.getSettings();

        // 设置与Js交互的权限
        webSettings.setJavaScriptEnabled(true);
        // 设置允许JS弹窗
        webSettings.setJavaScriptCanOpenWindowsAutomatically(true);

        // 先载入JS代码
        // 格式规定为:file:///android_asset/文件名.html
        mWebView.loadUrl("file:///android_asset/javascript.html");


        // 由于设置了弹窗检验调用结果,所以需要支持js对话框
        // webview只是载体，内容的渲染需要使用webviewChromClient类去实现
        // 通过设置WebChromeClient对象处理JavaScript的对话框
        //设置响应js 的Alert()函数
        mWebView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onJsAlert(WebView view, String url, String message, final JsResult result) {
                AlertDialog.Builder b = new AlertDialog.Builder(MyMainAct.this);
                b.setTitle("Alert");
                b.setMessage(message);
                b.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        result.confirm();
                    }
                });
                b.setCancelable(false);
                b.create().show();
                return true;
            }

        });

    }
*/

    public void onClick(View view) {
        // 通过Handler发送消息
        mWebView.post(new Runnable() {
            @Override
            public void run() {

                // 注意调用的JS方法名要对应上
                // 调用javascript的callJS()方法
//                mWebView.loadUrl("javascript:callJS()");

                // 只需要将第一种方法的loadUrl()换成下面该方法即可
                mWebView.evaluateJavascript("javascript:callJS()", new ValueCallback<String>() {
                    @Override
                    public void onReceiveValue(String value) {
                        //此处为 js 返回的结果
                        Log.e("ycj", "onReceiveValue:" + value);//value:null
                    }
                });

            }
        });


//        android.view.WindowManager wm = getWindowManager();
//        wm.getDefaultDisplay();
//
//        int left = mTv.getLeft();
//        int right = mTv.getRight();
//        int top = mTv.getTop();
//        int bott = mTv.getBottom();
//        Log.e("ycj---l,r,t,b:",left+","+right+","+top+","+bott);
//
//        float x = mTv.getX();float y = mTv.getY();
//        float translationX = mTv.getTranslationX();
//        float translationY = mTv.getTranslationY();
//
//        mTv.setLeft(left+30);
//        Intent intent = new Intent(this, MyMainAct.class);
//        startActivity(intent);
    }


    class MyScrollView extends View {

        public MyScrollView(Context context, AttributeSet attrs) {
            super(context, attrs);
        }

        public MyScrollView(Context context) {
            super(context);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            TextPaint paint = new TextPaint();
            paint.setAntiAlias(true);
            canvas.drawColor(Color.GRAY);
            for (int i = 10; i < 500; i++) {
                canvas.drawText("This is the scroll text.", 10, i, paint);
                i = i + 15;
            }
        }

        @Override
        protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
            String tag = "onMeasure";
            Log.e(tag, "Scroll View on measure...");
            setMeasuredDimension(200, 800);
        }

        @Override
        protected void onScrollChanged(int l, int t, int oldl, int oldt) {
            String tag = "onScrollChanged";
            Log.e(tag, "Scroll....");
            super.onScrollChanged(l, t, oldl, oldt);
        }
    }
}
