package com.lihang.dagger2stu.study.mforandroid;

import javax.inject.Inject;

/**
 * Created by leo
 * on 2019/9/4.
 */
public class AndroidBean {
    @Inject
    public AndroidBean() {

    }
}
