package com.lihang.dagger2stu.study.cstudy;


/**
 * Created by leo
 * on 2019/8/29.
 */
//灵魂
//灵魂里有钱
public class Soul {
    private int money;

    //  需要测试，打开注释
//  @Inject
    public Soul() {

    }

    public int getMoney() {
        return money;
    }

    public void setMoney(int money) {
        this.money = money;
    }
}
