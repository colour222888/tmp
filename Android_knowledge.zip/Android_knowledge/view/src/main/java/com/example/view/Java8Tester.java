package com.example.view;

import android.util.Log;

/*
        compileOptions {
            sourceCompatibility JavaVersion.VERSION_1_8
            targetCompatibility JavaVersion.VERSION_1_8
        }
     */
public class Java8Tester {
    public static void showTest() {
        Java8Tester tester = new Java8Tester();

        // 类型声明
        MathOperation addition = (int a, int b) -> a + b;

        // 不用类型声明
        MathOperation subtraction = (a, b) -> a - b;

        // 大括号中的返回语句
        MathOperation multiplication = (int a, int b) -> {
            return a * b;
        };

        // 没有大括号及返回语句
        MathOperation division = (int a, int b) -> a / b;

        //

        Log.e("ycj", "10 + 5 = " + tester.operate(10, 5, addition));
        Log.e("ycj", "10 - 5 = " + tester.operate(10, 5, subtraction));
        Log.e("ycj", "10 x 5 = " + tester.operate(10, 5, multiplication));
        Log.e("ycj", "10 / 5 = " + tester.operate(10, 5, division));

        // 不用括号
        GreetingService greetService1 = message ->
                Log.e("ycj", "Hello " + message);

        // 用括号
        GreetingService greetService2 = (message) ->
                Log.e("ycj", "Hello " + message);

        greetService1.sayMessage("Runoob");
        greetService2.sayMessage("Google");
    }

    interface MathOperation {
        int operation(int a, int b);
    }

    interface GreetingService {
        void sayMessage(String message);
    }

    private int operate(int a, int b, MathOperation mathOperation) {
        return mathOperation.operation(a, b);
    }

    private static int n = 0;

    public static void main(String[] args) {
        System.out.println("hello-----java");
//        int list[] = {1, 2, 3 ,  4, 5};
//        perm(list, 0, 4);
        int list[] = {1, 2, 3 ,4,5};
        perm(list, 0, 2);
    }

    private static void perm(int list[], int k, int m) {
        int i;
        if (k > m) {
            for (i = 0; i <= m; i++){
                System.out.print(list[i] + " ");//printf("%d ", list[i]);
            }
            System.out.println();
            n++;
        } else {
            for (i = k; i <= m; i++) {

                swap(list,k,i);//swap( & list[k], &list[i]);
                perm(list, k + 1, m);
                swap(list,k,i);//swap( & list[k], &list[i]);
            }
        }
    }

    private static void swap(int[]list,int index1, int index2){
            int tmp = list[index1];
            list[index1] = list[index2];
            list[index2] = tmp;
    }
}
