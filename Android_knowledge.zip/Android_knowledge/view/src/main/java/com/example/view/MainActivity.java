package com.example.view;

import android.app.ActionBar;
import android.app.Activity;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ScrollView;

import com.example.view.custom.MyView;
import com.example.view.custom.PieImageView;
import com.example.view.touch.MyTouchScrollView;
import com.example.view.touch.MyTouchView;
import com.example.view.touch.MyTouchViewGroup;

import java.util.HashMap;

import static android.view.ViewGroup.LayoutParams.MATCH_PARENT;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSystemService("asdf");
//        oldTest();

//        test();

//        setContentView(new MyView(this));

        MyTouchViewGroup myTouchViewGroup = new MyTouchViewGroup(this);
        myTouchViewGroup.setBackgroundColor(Color.BLUE);
        MyTouchView myTouchView = new MyTouchView(this);
        myTouchView.setBackgroundColor(Color.RED);
        myTouchViewGroup.addView(myTouchView,300, 100);
        setContentView(myTouchViewGroup,new ViewGroup.LayoutParams(500, 500));

//        ScrollView scrollView;
//        ListView listView;

//        MyTouchScrollView myTouchScrollView = new MyTouchScrollView(this);
//        myTouchScrollView.setBackgroundColor(Color.BLUE);
//        MyTouchView myTouchView = new MyTouchView(this);
//        myTouchView.setBackgroundColor(Color.RED);
//        myTouchScrollView.addView(myTouchView, 1000, 1000);
//        setContentView(myTouchScrollView);

    }

    private void test() {
        BaseAdapter baseAdapter;
        setContentView(R.layout.view_test);
//        findViewById(R.id.my_btn).getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
//            @Override
//            public void onGlobalLayout() {
//                View view =findViewById(R.id.my_btn);
//                Log.e("ycj", "MyButton w,h: " + view.getWidth() + "; " + view.getHeight());
//            }
//        });
//        findViewById(R.id.my_btn).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Log.e("ycj", "MyButton w,h-----------------: " + v.getWidth() + "; " + v.getHeight());
//            }
//        });
    }

    private void oldTest() {
        setContentView(R.layout.activity_main);

        PieImageView view = findViewById(R.id.pieImageView);
        view.setProgress(55);

        Log.e("ycj", "");
        Java8Tester.showTest();

    }


    public static void main(String[] args){
        HashMap<String,String>hashMap = new HashMap<>();
        hashMap.put("1","AA");
        String s = hashMap.get("1");
        String str = "123";
        System.out.println("----------->: "+str.hashCode());
    }
}
