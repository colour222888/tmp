package com.example.view.custom;

import android.content.Context;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.widget.FrameLayout;

public class MyFrameLayout extends FrameLayout {
    public MyFrameLayout(@NonNull Context context) {
        super(context);
    }

    public MyFrameLayout(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }

    public MyFrameLayout(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public MyFrameLayout(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
    }

//    @Override
//    public boolean onInterceptTouchEvent(MotionEvent ev) {
//        Log.e("ycj", "MyFrameLayout onInterceptTouchEvent");
//        /*boolean b = super.onInterceptTouchEvent(ev);
//        Log.e("ycj", "MyFrameLayout onInterceptTouchEvent :"+b);
//        return b;*/
//        Log.e("ycj", "MyFrameLayout onInterceptTouchEvent return true");
//        return true;
//    }
//
//    @Override
//    public boolean onTouchEvent(MotionEvent event) {
//        Log.e("ycj", "MyFrameLayout onTouchEvent");
//        /*boolean b = super.onTouchEvent(event);
//        Log.e("ycj", "MyFrameLayout onTouchEvent b:"+b);
//        return b;*/
//        Log.e("ycj", "MyFrameLayout onTouchEvent true");
//        return true;
//    }
//
//    @Override
//    public boolean dispatchTouchEvent(MotionEvent ev) {
//        Log.e("ycj", "MyFrameLayout dispatchTouchEvent");
//        boolean b = super.dispatchTouchEvent(ev);
//        Log.e("ycj", "MyFrameLayout dispatchTouchEvent b:"+b);
//        return b;
//    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        MeasureSpec.getMode(widthMeasureSpec);
        Log.e("ycj","MyFrameLayout onMeasure widthMeasureSpec: "+getModeStr(MeasureSpec.getMode(widthMeasureSpec))+"; "+MeasureSpec.getSize(widthMeasureSpec));
        Log.e("ycj","MyFrameLayout onMeasure heightMeasureSpec: "+getModeStr(MeasureSpec.getMode(heightMeasureSpec))+"; "+MeasureSpec.getSize(heightMeasureSpec));
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
    }

    private String getModeStr(int modeValue){
        if (modeValue == MeasureSpec.AT_MOST){
            return "AT_MOST";
        }else if (modeValue == MeasureSpec.EXACTLY){
            return "EXACTLY";
        }else {
            return "UNSPECIFIED";
        }
    }

    @Override
    protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
        Log.e("ycj","MyFrameLayout onLayout: "+left+";"+top+";"+right+";"+bottom);
        super.onLayout(changed, left, top, right, bottom);
    }
}
