package com.example.view;

import android.os.HandlerThread;
import android.os.Looper;
import android.util.Log;
import android.util.Printer;

public class PerformanceMonitoring {
    /**
     * 检查当前 handler 线程方法耗时
     */
    public static void monitoringTakeUpTime(final String threadName) {
        Looper.myLooper().setMessageLogging(new Printer() {
            private long mStartTime = 0;

            @Override
            public void println(String x) {
                if (x.startsWith(">>>>> Dispatching to")) {
                    mStartTime = System.currentTimeMillis();
                    // 埋一个 60ms 延时的警告炸弹，或者写入到日志文件，方便线上分析
                } else if (x.startsWith("<<<<< Finished to")) {
                    // 去拆炸弹，如果超过了 60ms
                    long executeTime = System.currentTimeMillis() - mStartTime;
//                    if (executeTime > 60) {
                    if (executeTime > 16) {
                        // 当前 handler 线程方法有耗时
                        // 思考？怎么检测是哪个方法耗时
                        Log.e("ycj_monitor", "当前" + threadName + "线程有耗时, time:"+executeTime);
                    }
                }
            }
        });
    }

    // 如果真正要监听是哪个方法耗时？怎么做
    // 思路，可以开一个线程去做，做一个埋炸弹和拆炸弹的流程，这个是参考 ANR 的源码
    // ANR 的原理？
    // 性能监听有一个严格要求不能影响原来的性能
}
