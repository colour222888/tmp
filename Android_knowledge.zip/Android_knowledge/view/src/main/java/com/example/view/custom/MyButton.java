package com.example.view.custom;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.Button;

public class MyButton extends Button {
    public MyButton(Context context) {
        super(context);
    }

    public MyButton(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public MyButton(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public MyButton(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
    }

//    @Override
//    public boolean onTouchEvent(MotionEvent event) {
//        Log.e("ycj", "MyButton onTouchEvent");
//        boolean b = super.onTouchEvent(event);
//        Log.e("ycj", "MyButton onTouchEvent b:"+b);
//        return b;
//    }
//
//    @Override
//    public boolean dispatchTouchEvent(MotionEvent ev) {
//        Log.e("ycj", "MyButton dispatchTouchEvent");
//        boolean b = super.dispatchTouchEvent(ev);
//        Log.e("ycj", "MyButton dispatchTouchEvent b:"+b);
//        return b;
//    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        MeasureSpec.getMode(widthMeasureSpec);
        Log.e("ycj", "MyButton onMeasure widthMeasureSpec: " + getModeStr(MeasureSpec.getMode(widthMeasureSpec)) + "; " + MeasureSpec.getSize(widthMeasureSpec));
        Log.e("ycj", "MyButton onMeasure heightMeasureSpec: " + getModeStr(MeasureSpec.getMode(heightMeasureSpec)) + "; " + MeasureSpec.getSize(heightMeasureSpec));
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
    }

    private String getModeStr(int modeValue) {
        if (modeValue == MeasureSpec.AT_MOST) {
            return "AT_MOST";
        } else if (modeValue == MeasureSpec.EXACTLY) {
            return "EXACTLY";
        } else {
            return "UNSPECIFIED";
        }
    }

    @Override
    protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
        Log.e("ycj", "MyButton onLayout: " + left + ";" + top + ";" + right + ";" + bottom);
        super.onLayout(changed, left, top, right, bottom);
    }

    @Override
    public void onWindowFocusChanged(boolean hasWindowFocus) {
        Log.e("ycj", "MyButton onWindowFocusChanged: " + getWidth() + "; " + getHeight());
        super.onWindowFocusChanged(hasWindowFocus);
    }


    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        Paint paint = new Paint();
        paint.setColor(Color.BLUE);
        Rect rect = new Rect();
        rect.left = getLeft();
        rect.top = getTop();
        rect.right = getRight();
        rect.bottom = getBottom();
        canvas.drawRect(rect, paint);
        canvas.drawCircle(getWidth() / 2, getHeight() / 2, getWidth() / 2, paint);
    }
}
