package com.example.view.touch;

import android.content.Context;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;

public class MyTouchViewGroup extends ViewGroup {
    public MyTouchViewGroup(Context context) {
        super(context);
    }

    public MyTouchViewGroup(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public MyTouchViewGroup(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        //todo
    }

    @Override
    protected void onLayout(boolean changed, int l, int t, int r, int b) {
        Log.e("ycj", "MyTouchViewGroup l,t,r,b:" + l + "," + t + "," + r + "," + b);
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            View view = getChildAt(i);
            Log.e("ycj", "MyTouchViewGroup l,t,getMeasuredWidth(),getMeasuredHeight():" + l + "," + t + "," + view.getMeasuredWidth() + "," + view.getMeasuredHeight());
            view.layout(l, t, view.getMeasuredWidth(), view.getMeasuredHeight());
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        Log.e("ycj", "MyTouchViewGroup onTouchEvent begin");
        boolean b = super.onTouchEvent(event);
        Log.e("ycj", "MyTouchViewGroup onTouchEvent b:" + b);
        return b;
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        Log.e("ycj", "MyTouchViewGroup dispatchTouchEvent begin");
        boolean b = super.dispatchTouchEvent(ev);
        Log.e("ycj", "MyTouchViewGroup dispatchTouchEvent b:" + b);
        return b;
    }
}
