package com.example.view.touch;

import android.content.Context;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.widget.ScrollView;

public class MyTouchScrollView extends ScrollView {
    public MyTouchScrollView(Context context) {
        super(context);
    }

    public MyTouchScrollView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public MyTouchScrollView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        int childCount = getChildCount();
        final int action = ev.getAction();
        boolean inTercept = super.onInterceptTouchEvent(ev);
        switch (action & MotionEvent.ACTION_MASK) {
            case MotionEvent.ACTION_DOWN:
                Log.e("ycj","MyTouchScrollView dispatchTouchEvent ACTION_DOWN inTercept:"+inTercept);
                Log.e("ycj","MyTouchScrollView dispatchTouchEvent ACTION_DOWN childCount:"+childCount);
                break;
            case MotionEvent.ACTION_MOVE:
                Log.e("ycj","MyTouchScrollView dispatchTouchEvent ACTION_MOVE inTercept:"+inTercept);
                break;
        }
        return super.dispatchTouchEvent(ev);
    }

    @Override
    public boolean onTouchEvent(MotionEvent ev) {
        final int action = ev.getAction();
        switch (action & MotionEvent.ACTION_MASK) {
            case MotionEvent.ACTION_DOWN:
                Log.e("ycj","MyTouchScrollView onTouchEvent ACTION_DOWN ");
                break;
            case MotionEvent.ACTION_MOVE:
                Log.e("ycj","MyTouchScrollView onTouchEvent ACTION_MOVE ");
                break;
        }
        return super.onTouchEvent(ev);
    }
}
