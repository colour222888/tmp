package com.example.view.touch;

import android.content.Context;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;

public class MyTouchView extends View {
    public MyTouchView(Context context) {
        super(context);
    }

    public MyTouchView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }

    public MyTouchView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int heightSize = MeasureSpec.getSize(heightMeasureSpec);
        int widthSize = MeasureSpec.getSize(widthMeasureSpec);
//        MeasureSpec.
//        Log.e("ycj", "MyTouchViewGroup l,t,r,b:" + l + "," + t + "," + r + "," + b);
        Log.e("ycj", "MyTouchView heightSize,widthSize:" + heightSize + "," + widthSize );
        setMeasuredDimension(widthSize, heightSize);
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent event) {
        Log.e("ycj","MyTouchView dispatchTouchEvent begin");
        boolean b = super.dispatchTouchEvent(event);
        Log.e("ycj","MyTouchView dispatchTouchEvent b:"+b);
        return b;
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        Log.e("ycj","MyTouchView onTouchEvent begin:");
        boolean b = super.onTouchEvent(event);
        Log.e("ycj","MyTouchView onTouchEvent b:"+b);
//        Log.e("ycj","MyTouchView onTouchEvent b:"+Log.getStackTraceString(new Throwable("11111")));
        return b;
    }
}
