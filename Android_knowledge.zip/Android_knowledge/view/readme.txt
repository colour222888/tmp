创建各种xml资源文件：
选择模块右键->new->android resource file
填写file name 和选择resource type(Animation,Animator,Color,Drawable,Font,Layout,Menu,Navigation,Transition,values,Xml)
各种xml文件的根节点：
Animation,  -><set>:               <alpha>,<rotate>,<scale>,<set>,<translate>

Animator,   -><set>:               <animator>,<objectAnimator>,<propertyValuesHolder>,<set>

Color,      -><selector>:          <item>

Drawable,   -><selector>:  <item>
            -><shape>:     <solid>,<corners>,<stroke>
            -><vector>:    <path>


Font,       -><font-family>:       <font>

Layout,     -><ConstraintLayout>:

Menu,       -><menu>:              <item>,<group>

Navigation, -><navigation>:        <action>,<activity>,<argument>,<deepLink>,<fragment>,<include>,<navigation>

Transition, -><transitionManager>: <transition>

values,     -><resources>:         <item>,<array>,<attr>,<bool>,<color>,<declare-styleable>,<dimen>,<drawable>,<eat-comment>,
                                   <fraction>,<integer>,<integer-array>,<plurals>,<string>,<string-array>,<style>,

Xml         -><PreferenceScreen>:  <CheckBoxPreference>,<EditTextPreference>,<ListPreference>,<MultiSelectListPreference>,
                                    <PreferenceCategory>,<Preference>,<PreferenceScreen>,<RingtonePreference>,<SwitchPreference>,



