package colour.server;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import org.wangchenlong.wcl_aidl_demo.R;

public class ServiceActivity extends Activity implements View.OnClickListener {
    private static final String TAG = "DEBUG-COLOUR-" + ServiceActivity.class.getSimpleName();
    private MyService.DownloadBinder downloadBinder;

    private ServiceConnection connection = new ServiceConnection() {

        @Override
        public void onServiceDisconnected(ComponentName name) {
            Log.d(TAG, "ServiceConnection.onServiceDisconnected executed");
        }

        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            Log.d(TAG, "ServiceConnection.onServiceConnected executed");
            downloadBinder = (MyService.DownloadBinder) service;
            downloadBinder.startDownload();
            downloadBinder.getProgress();
        }

        @Override
        public void onBindingDied(ComponentName name) {
            Log.d(TAG, "ServiceConnection.onBindingDied executed");
        }

        @Override
        public void onNullBinding(ComponentName name) {
            Log.d(TAG, "ServiceConnection.onNullBinding executed");
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_service);
        Button startService = (Button) findViewById(R.id.start_service);
        Button stopService = (Button) findViewById(R.id.stop_service);
        startService.setOnClickListener(this);
        stopService.setOnClickListener(this);
        Button bindService = (Button) findViewById(R.id.bind_service);
        Button unbindService = (Button) findViewById(R.id.unbind_service);
        bindService.setOnClickListener(this);
        unbindService.setOnClickListener(this);
        Button startIntentService = (Button) findViewById(R.id.start_intent_service);
        startIntentService.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        int i = v.getId();
        if (i == R.id.start_service) {
            Intent startIntent = new Intent(this, MyService.class);
            startService(startIntent); // 启动服务

        } else if (i == R.id.stop_service) {
            Intent stopIntent = new Intent(this, MyService.class);
            stopService(stopIntent); // 停止服务

        } else if (i == R.id.bind_service) {
            Intent bindIntent = new Intent(this, MyService.class);
            bindService(bindIntent, connection, BIND_AUTO_CREATE); // 绑定服务

        } else if (i == R.id.unbind_service) {
            unbindService(connection); // 解绑服务

        } else if (i == R.id.start_intent_service) {// 打印主线程的id
            Log.d(TAG, "Thread id is " + Thread.currentThread().getId());
            Intent intentService = new Intent(this, MyIntentService.class);
            startService(intentService);

        } else {
        }
    }
}
/*
 * 1.service 的生命周期函数：onCreate,onStart(或onStartCommand),onBind,onUnbind,onDestroy
 * 2.service有两种启动方式：一种是startService(startIntent)(对应的关闭:stopService(stopIntent))，
 * 另一种是bindService(bindIntent, connection, BIND_AUTO_CREATE)(对应的关闭:unbindService(connection))
 * 3.两种方法是可以一起使用的，但是必须要先使用startService方法，然后在使用bindService方法，当然了，当app销毁的时候还是需要调用unbindService方法解绑的
 *
 *  点击三次startService，三次stopService（只执行一次oncreate和destroy。多次onstartCommand）
 *  MyService.onCreate executed
 *  Myservice.onStartCommand executed
 *  Myservice.onStartCommand executed
 *  Myservice.onStartCommand executed
 *  Myservice.onDestroy executed
 *
 *  点击三次bindService，三次unbindService（多次点击bindService只会执行一次。多次点击unbindService第二次会崩）
 *  MyService.onCreate executed
 *  MyService.onBind executed
 *  ServiceConnection.onServiceConnected executed
 *  DownloadBinder.startDownload executed
 *  DownloadBinder.getProgress executed
 *  Myservice.onUnbind executed
 *  Myservice.onDestroy executed
 *
 *  onCreate -> onStartCommand -> service_running(the service is stoppend by itself or a client) -> onDestroy -> Service shut down
 *  onCreate -> onBind -> Cients are bound to service(All clients unbind by calling unbindService()) -> onUnbind -> onDestroy -> Service shut down
 *
 * service特点：它无法与用户直接进行交互、它必须由用户或者其他程序显式的启动、它的优先级比较高，它比处于前台的应用优先级低，
 *              但是比后台的其他应用优先级高，这就决定了当系统因为缺少内存而销毁某些没被利用的资源时，它被销毁的概率很小
 *
 *  todo：1.两种service启动方式的使用场景，2.service与thread的使用场景与区别，3.service是否可以动态配置而不是在manifest注册
 *
 *  那为什么要用服务呢，初步理解是服务是为了更好地管理线程。试想，当我们在某一个activity中启动一个新的Thread的后，我们一般会在新线程
 *  中执行一些耗时操作，甚至有时我们需要在此activity被销毁后线程任然执行。但是这时候我们就会失去线程的引用，无法再对线程进行控制。而
 *  借助服务的话，我们可以下服务中启动线程，即使activity被销毁了，只要我们能与服务建立联系，我们就能够对线程进行有效的控制。
 *
 *  startService与bindService混合使用
 *  使用场景：在activity中要得到service对象进而能调用对象的方法，但同时又不希望activity finish的时候service也被destory了，startService和bindService混合使用就派上用场了。
 * */
