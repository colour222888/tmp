package com.example.viewstudy;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class ViewMainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_view_main);//组装view（继承了layout。添加了控件属性）
        setContentView(R.layout.activity_pie_image);
//        setContentView(R.layout.activity_flow_layout);
    }
}
