package colour.broadcast;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

public class HighPriorityReceiver extends BroadcastReceiver {
    private static final String TAG = "DEBUG-COLOUR-" + HighPriorityReceiver.class.getSimpleName();

    @Override
    public void onReceive(Context context, Intent intent) {
        Log.d(TAG, "HighPriorityReceiver.onReceive executed!!");
        //拦截广播
//        abortBroadcast();
        //传递结果到下一个广播接收器
        int code = 285249;
        String data = "hello";
        Bundle bundle = null;
        setResult(code, data, bundle);

    }
}
