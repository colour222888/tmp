package colour.broadcast;

import android.app.Activity;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import java.lang.ref.WeakReference;

public class BroadcastActivity extends Activity implements View.OnClickListener {
    private static final String TAG = "DEBUG-COLOUR-" + BroadcastActivity.class.getSimpleName();
    private MyBroadcastReceiverDynamic mMyBroadcastReceiverDynamic;
    private HighPriorityReceiver mHighPriorityReceiver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_broadcast);

        mMyBroadcastReceiverDynamic = new MyBroadcastReceiverDynamic();
        registerReceiver(mMyBroadcastReceiverDynamic, new IntentFilter("colour.broadcast.MyBroadcastReceiverDynamic"));

        mHighPriorityReceiver = new HighPriorityReceiver();
        IntentFilter intentFilter = new IntentFilter("colour.broadcast");
        intentFilter.setPriority(3000);
        registerReceiver(mHighPriorityReceiver, intentFilter);

        Button start_broadcast = (Button) findViewById(R.id.start_broadcast);
        start_broadcast.setOnClickListener(this);

        Button start_ordered_broadcast = (Button) findViewById(R.id.start_ordered_broadcast);
        start_ordered_broadcast.setOnClickListener(this);

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Log.e("ycj", "this:" + this + ";BroadcastActivity.this:" + BroadcastActivity.this);
                    Thread.sleep(50000);
                    Log.e("ycj", "sleep 20000");
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(mMyBroadcastReceiverDynamic);
        unregisterReceiver(mHighPriorityReceiver);
        Log.e("ycj", "BroadcastActivity onDestroy");
        System.gc();
    }

    @Override
    protected void finalize() throws Throwable {
        Log.e("ycj", "BroadcastActivity finalize");
        super.finalize();
    }

    @Override
    public void onClick(View v) {
        int i = v.getId();
        if (i == R.id.start_broadcast) {

            Intent startIntent = new Intent();
            startIntent.setAction("colour.broadcast.MyBroadcastReceiverStatic");
            sendBroadcast(startIntent);

            Intent startIntent_ = new Intent();
            startIntent_.setAction("colour.broadcast.MyBroadcastReceiverDynamic");
            sendBroadcast(startIntent_);

        } else if (i == R.id.start_ordered_broadcast) {
//            Intent stopIntent = new Intent(this, MyService.class);
//            stopService(stopIntent); // 停止服务
            Intent intent = new Intent();
            intent.setAction("colour.broadcast");
            sendOrderedBroadcast(intent, null);
        }
    }
}
