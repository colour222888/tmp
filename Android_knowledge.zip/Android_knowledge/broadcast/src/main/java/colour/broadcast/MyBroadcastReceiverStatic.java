package colour.broadcast;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

public class MyBroadcastReceiverStatic extends BroadcastReceiver {
    private static final String TAG = "DEBUG-COLOUR-" + MyBroadcastReceiverStatic.class.getSimpleName();

    @Override
    public void onReceive(Context context, Intent intent) {
        Log.d(TAG, "MyBroadcastReceiverStatic.onReceive executed");
    }
}
