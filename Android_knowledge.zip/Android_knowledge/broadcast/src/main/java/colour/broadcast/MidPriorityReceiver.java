package colour.broadcast;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

public class MidPriorityReceiver extends BroadcastReceiver {
    private static final String TAG = "DEBUG-COLOUR-" + MidPriorityReceiver.class.getSimpleName();

    @Override
    public void onReceive(Context context, Intent intent) {
        Log.d(TAG, "MidPriorityReceiver.onReceive executed");
        Log.d(TAG, "MidPriorityReceiver.onReceive intent.getAction():" + intent.getAction());
        Log.d(TAG, "MidPriorityReceiver.onReceive getResultCode:" + getResultCode());
        Log.d(TAG, "MidPriorityReceiver.onReceive getResultData:" + getResultData());
        Log.d(TAG, "MidPriorityReceiver.onReceive getResultExtras:" + getResultExtras(true));
    }
}
