package com.example.servicestudy;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.MotionEvent;
import android.view.View;

public class ServiceMainActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.service_act_main);
        initView();
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.bind_service_btn) {

        } else if (v.getId() == R.id.start_service_btn) {

        }
    }

    private void initView() {
        findViewById(R.id.bind_service_btn).setOnClickListener(this);
        findViewById(R.id.start_service_btn).setOnClickListener(this);
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        return super.dispatchTouchEvent(ev);
    }
}
