package colour.kongzhong.com.android_knowledge;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.os.Process;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;

import com.example.servicestudy.ServiceMainActivity;
import com.example.viewstudy.ViewMainActivity;

import org.json.JSONObject;

import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.Map;

import colour.aidl.AIDLActivity;
import colour.broadcast.BroadcastActivity;
import colour.kongzhong.com.android_knowledge.servicetest.MyService;
import colour.server.ServiceActivity;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private static final String TAG = "ycj_" + MainActivity.class.getSimpleName();
    private MyService.DownloadBinder downloadBinder;
    private ServiceConnection connection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            Log.d("MyService", "onServiceConnected executed");
            downloadBinder = (MyService.DownloadBinder) service;
            downloadBinder.startDownload();
            downloadBinder.getProgress();
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            Log.d("MyService", "onServiceDisconnected executed");
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        intView();

//        testShow();

//        handlerTest();

//        showServer_aidlTest();  //  server_aidl module test aidl注册监听


////        Intent startIntent = new Intent(this, MyService.class);
////        startService(startIntent); // 启动服务
//
//        Intent bindIntent = new Intent(this, MyService.class);
//        bindService(bindIntent, connection, BIND_AUTO_CREATE); // 绑定服务
//
//        findViewById(R.id.btn1).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
////                Intent stopIntent = new Intent(MainActivity.this, MyService.class);
////                stopService(stopIntent); // 停止服务
//
//                unbindService(connection); // 解绑服务
//            }
//        });
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        Log.e("ycj", "mainActivity dispatchTouchEvent");
        return super.dispatchTouchEvent(ev);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        Log.e("ycj", "mainActivity onTouchEvent");
        return super.onTouchEvent(event);
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.activity_fragment_btn) {
            startActivity(new Intent(this, ServiceMainActivity.class));
        } else if (v.getId() == R.id.service_btn) {
            startActivity(new Intent(this, ServiceMainActivity.class));
        } else if (v.getId() == R.id.broadcast_btn) {
            startActivity(new Intent(this, ServiceMainActivity.class));
        } else if (v.getId() == R.id.view_btn) {
            startActivity(new Intent(this, ViewMainActivity.class));
        }
    }

    private void intView() {
        findViewById(R.id.img_1).setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                Log.e("ycj_test", "img1 event.getAction()" + event.getAction());
                return false;
            }
        });
        findViewById(R.id.img_2).setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                Log.e("ycj_test", "img2 event.getAction()" + event.getAction());
                return false;
            }
        });
        findViewById(R.id.activity_fragment_btn).setOnClickListener(this);
        findViewById(R.id.service_btn).setOnClickListener(this);
        findViewById(R.id.broadcast_btn).setOnClickListener(this);
        findViewById(R.id.view_btn).setOnClickListener(this);

        runOnUiThread(null);
    }

    private void testShow() {
        //broadcast demo
        Intent intent = new Intent(this, BroadcastActivity.class);
        startActivity(intent);

        boolean b = BroadcastActivity.class.isAssignableFrom(Activity.class.getClass());
        Log.d("ycj", "b1:" + b);

        Map map = new HashMap();
        Object object1 = map.put(String.class.getClass(), 1);
        Object object2 = map.put(String.class.getClass(), 2);
        Log.d("ycj", "object1,object2::" + object1 + "," + object2);
        Log.d("ycj", "value:" + map.get(String.class.getClass()));
        testFuc();
    }

    private void testFuc() {
        try {
            Map map = new HashMap();
            map.put("1", 1);
            map.put("2", "2");
            map.put("3", Activity.class.getClasses());

            Map map1 = new HashMap();
            map1.put("11", "11");
            map.put("4", map1);

            Map<?, ?> contentsTyped = (Map<?, ?>) map;
            for (Map.Entry<?, ?> entry : contentsTyped.entrySet()) {
                /*
                 * Deviate from the original by checking that keys are non-null and
                 * of the proper type. (We still defer validating the values).
                 */
                Object i = entry.getKey();
                String key = (String) i;
                if (key == null) {
                    throw new NullPointerException("key == null");
                }
//                nameValuePairs.put(key, wrap(entry.getValue()));
            }

            JSONObject jsonObject = new JSONObject(map);
            for (Object jsonField : map.keySet()) {
                String key = String.valueOf(jsonField);
                Object value = map.get(key);
                if (value == null ||
                        value.getClass().getPackage().getName().equals("java.lang")) {
                    jsonObject.put(key, map.get(key));
                } else {
//                    JSONMapper mapper = factory.getMapper(value.getClass());
//                    jsonObject.put(key, new JSONObject(mapper.getJson(value)));
                    Log.d("ycj", "else");
                }
            }
        } catch (Exception e) {
            Log.d("ycj", "Exception e:" + e);
        }

    }

    private void handlerTest() {
        Handler handler = new Handler() {
            @Override
            public void handleMessage(Message msg) {
                super.handleMessage(msg);
                //主线程
                Log.e("ycj", "handleMessage thread id:" + Thread.currentThread().getId());
            }
        };
        Message message = new Message();
        //主线程
        Log.e("ycj", "sendMessage thread id:" + Thread.currentThread().getId());
        handler.sendMessage(message);

        new Thread(new Runnable() {
            @Override
            public void run() {
                Looper.prepare();
                Looper.loop();
                Handler handler1 = new Handler() {
                    @Override
                    public void handleMessage(Message msg) {
                        super.handleMessage(msg);
                        Log.e("ycj", "handleMessage thread id otherthread:" + Thread.currentThread().getId());
                    }
                };
                Log.e("ycj", "sendMessage thread id ohterthread:" + Thread.currentThread().getId());
                handler1.sendMessage(new Message());
                Looper.loop();//最后才调用因为 该方法是阻塞方法
            }
        }).start();

        Integer.parseInt("11");
    }

    private void showServer_aidlTest(){
        //server_aidl module demo

        Intent intent = new Intent(this,AIDLActivity.class);
        startActivity(intent);

//        Intent intent = new Intent(this,ServiceActivity.class);
//        startActivity(intent);
//        Log.d(TAG, "MyService.onStartCommand threadId,Process.myPid:"+Thread.currentThread().getId()+","+Process.myPid());
    }
}
