package colour.kongzhong.com.android_knowledge;


import java.lang.ref.WeakReference;

public class JavaMain {
    public static void main(String[] args) {
        WeakReference<Person> weakReference = new WeakReference<>(new Person("ken", 11));
        System.out.println("ycj-- weakReference.get():" + weakReference.get());
        System.gc();
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        Person person = weakReference.get();
        if (person == null) {
            System.out.println("ycj-- weakReference clean person");
        } else {
            System.out.println("ycj-- weakReference not clean person");
        }
    }
}
