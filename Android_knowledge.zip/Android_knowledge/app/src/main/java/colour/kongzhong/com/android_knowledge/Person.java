package colour.kongzhong.com.android_knowledge;

public class Person {
    public String mName;
    public int mAge;

    public Person(String name, int age) {
        mName = name;
        mAge = age;
    }

    @Override
    protected void finalize() throws Throwable {
        super.finalize();
        System.out.println("name： " + mName + " finalize。");
    }

    @Override
    public String toString() {
        return "name:" + mName + ",toString";
    }
}
