package binder.v3;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import android.support.annotation.Nullable;
import android.util.Log;

import colour.kongzhong.com.android_knowledge.IGradeService;
import colour.kongzhong.com.android_knowledge.R;

public class AidlActivity extends Activity {
    private IGradeService mIGradeService;//aidl文件生成的java类

    private final ServiceConnection mServiceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            // 连接服务成功，根据是否跨进程获取BinderProxy或者GradeBinder实例
//            mBinderProxy = BinderProxy.asInterface(service);
            mIGradeService = IGradeService.Stub.asInterface(service);
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            mIGradeService = null;
        }
    };

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_binder);

        findViewById(R.id.bindservice).setOnClickListener(v -> bindGradService());
        findViewById(R.id.getstudengrade).setOnClickListener(v -> {
            try {
                int grade = mIGradeService.getStudentGrade("kk");
                Log.e("ycj","");
            } catch (RemoteException e) {
                e.printStackTrace();
            }
        });
    }

    private void bindGradService() {
        String action = "android.intent.action.server.gradev2service";
        Intent intent = new Intent(action);
        intent.setPackage(getPackageName());
        bindService(intent, mServiceConnection, BIND_AUTO_CREATE);
    }
}
