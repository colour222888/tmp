package binder.v3;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.support.annotation.Nullable;

import java.util.HashMap;
import java.util.Map;

import colour.kongzhong.com.android_knowledge.IGradeService;

//成绩信息服务
public class AidlService extends Service {
    private final Map<String, Integer> gradeMap = new HashMap<>();

    @Override
    public void onCreate() {
        super.onCreate();
        gradeMap.put("kk", 66);
        gradeMap.put("hh", 77);
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return new IGradeService.Stub() {
            @Override
            public void basicTypes(int anInt, long aLong, boolean aBoolean, float aFloat, double aDouble, String aString) {

            }

            @Override
            public int getStudentGrade(String name) {
                return gradeMap.containsKey(name) ? gradeMap.get(name) : -1;
            }
        };
    }
}
