package binder.v2;

import android.os.IBinder;
import android.os.Parcel;
import android.os.RemoteException;
import android.util.Log;

public class BinderProxy implements IGradeInterface {
    public static final int REQUEST_CODE = 1000;
    // 被代理的Binder
    private final IBinder mBinder;

    // 私有化构造方法
    private BinderProxy(IBinder binder) {
        mBinder = binder;
    }

    // 通过Binde读取成绩
    @Override
    public int getStudentGrade(String name) {
        Parcel data = Parcel.obtain();
        Parcel reply = Parcel.obtain();
        int grade = -1;
        Log.e("ycj", "BinderProxy data.writeString(name): " + name);
        data.writeString(name);
        try {
            if (mBinder == null) {
                throw new IllegalStateException("Need Bind Remote Server...");
            }
            mBinder.transact(REQUEST_CODE, data, reply, 0);
            grade = reply.readInt();
            Log.e("ycj", "BinderProxy reply.readInt(): " + grade);
        } catch (RemoteException e) {
            e.printStackTrace();
        }
        return grade;
    }

    // 实例化Binder代理类的对象
    public static IGradeInterface asInterface(IBinder iBinder) {
        if (iBinder == null) {
            return null;
        }

        if (iBinder instanceof IGradeInterface) {
            Log.e("ycj", "asInterface 当前进程");
            // 如果是同一个进程的请求，则直接返回Binder
            return (IGradeInterface) iBinder;
        } else {
            Log.e("ycj", "asInterface 远程进程");
            // 如果是跨进程查询则返回Binder的代理对象
            return new BinderProxy(iBinder);
        }
    }
}
