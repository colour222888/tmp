package binder.v2;

import android.os.Binder;
import android.os.Parcel;
import android.os.RemoteException;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;

import java.util.HashMap;
import java.util.Map;

public class GradeBinder extends Binder implements IGradeInterface {
    private static final int REQUEST_CODE = 1000;
    private Map<String, Integer> mGradeMap;

    public GradeBinder(Map<String, Integer> gradeMap) {
        mGradeMap = gradeMap;
    }

    @Override
    public int getStudentGrade(String name) {
        Log.e("ycj", "GradeBinder getStudentGrade(String name): " + name);
        return mGradeMap.containsKey(name) ? mGradeMap.get(name) : -1;
    }

    @Override
    protected boolean onTransact(int code, @NonNull Parcel data, @Nullable Parcel reply, int flags) throws RemoteException {
        if (code == REQUEST_CODE) {
            String name = data.readString();
            Log.e("ycj", "GradeBinder String name = data.readString(): " + name);
            int studentGrade = getStudentGrade(name);
            if (reply != null)
                Log.e("ycj", "GradeBinder reply.writeInt(studentGrade): " + studentGrade);
            reply.writeInt(studentGrade);
            return true;
        }
        return super.onTransact(code, data, reply, flags);
    }
}
