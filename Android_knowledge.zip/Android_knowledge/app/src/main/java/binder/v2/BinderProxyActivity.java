package binder.v2;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import android.os.RemoteException;
import android.support.annotation.Nullable;
import android.util.Log;

import colour.kongzhong.com.android_knowledge.R;

public class BinderProxyActivity extends Activity {
    // 此处可能是BinderProxy也可能是GradeBinder
    private IGradeInterface mBinderProxy;

    private final ServiceConnection mServiceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            // 连接服务成功，根据是否跨进程获取BinderProxy或者GradeBinder实例
            mBinderProxy = BinderProxy.asInterface(service);
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            mBinderProxy = null;
        }
    };

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_binder);

        findViewById(R.id.bindservice).setOnClickListener(v -> bindGradService());
        findViewById(R.id.getstudengrade).setOnClickListener(v -> mBinderProxy.getStudentGrade("kk"));
    }

    private void bindGradService() {
        String action = "android.intent.action.server.gradev2service";
        Intent intent = new Intent(action);
        intent.setPackage(getPackageName());
        bindService(intent, mServiceConnection, BIND_AUTO_CREATE);
    }
}
