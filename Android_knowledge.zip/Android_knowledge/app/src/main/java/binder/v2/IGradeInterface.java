package binder.v2;

public interface IGradeInterface {
    int getStudentGrade(String name);
}
