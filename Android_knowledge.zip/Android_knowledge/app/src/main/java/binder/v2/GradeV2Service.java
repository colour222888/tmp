package binder.v2;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;
import android.os.Parcel;
import android.os.RemoteException;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;

import java.util.HashMap;
import java.util.Map;

//成绩信息服务
public class GradeV2Service extends Service {
    public static final int REQUEST_CODE = 1000;
    private Map<String, Integer> gradeMap = new HashMap<>();

    @Override
    public void onCreate() {
        super.onCreate();
        gradeMap.put("kk", 66);
        gradeMap.put("hh", 77);
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return new GradeBinder(gradeMap);
    }
}
