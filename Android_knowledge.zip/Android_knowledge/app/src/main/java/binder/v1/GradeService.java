package binder.v1;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;
import android.os.Parcel;
import android.os.RemoteException;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;

import java.util.HashMap;
import java.util.Map;

//成绩信息服务
public class GradeService extends Service {
    private static final int REQUEST_CODE = 1000;
    private Map<String, Integer> gradeMap = new HashMap<>();
    private IBinder iBinder = new Binder() {
        @Override
        protected boolean onTransact(int code, @NonNull Parcel data, @Nullable Parcel reply, int flags) throws RemoteException {
            if (code == REQUEST_CODE) {
                String name = data.readString();
                Log.e("ycj", "GradeService String name = data.readString(): " + name);
                int grade = getStudentGrade(name);
                if (reply != null){
                    Log.e("ycj", "GradeService reply.writeInt(grade): " + grade);
                    reply.writeInt(grade);
                }
                return true;
            }
            return super.onTransact(code, data, reply, flags);
        }

        public int getStudentGrade(String name) {
            return gradeMap.containsKey(name) ? gradeMap.get(name) : -1;
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        gradeMap.put("kk", 66);
        gradeMap.put("hh", 77);
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return iBinder;
    }
}
