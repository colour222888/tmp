package binder.v1;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import android.os.RemoteException;
import android.support.annotation.Nullable;
import android.util.Log;

import colour.kongzhong.com.android_knowledge.R;

public class BinderActivity extends Activity {
    private IBinder mRemoteBinder;

    private final ServiceConnection mServiceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            mRemoteBinder = service;
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            mRemoteBinder = null;
        }
    };

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_binder);

        findViewById(R.id.bindservice).setOnClickListener(v -> bindGradService());
        findViewById(R.id.getstudengrade).setOnClickListener(v -> getStudentGrade("kk"));
    }

    private void bindGradService() {
        String action = "android.intent.action.server.gradeservice";
        Intent intent = new Intent(action);
        intent.setPackage(getPackageName());
        bindService(intent, mServiceConnection, BIND_AUTO_CREATE);
    }


    // 从远程服务查询学生成绩
    public static final int REQUEST_CODE = 1000;

    private int getStudentGrade(String name) {
        Parcel data = Parcel.obtain();
        Parcel reply = Parcel.obtain();
        int grade = 0;
        data.writeString(name);
        Log.e("ycj", "BinderActivity data.writeString(name): " + name);
        try {
            if (mRemoteBinder == null) {
                throw new IllegalStateException("Need Bind Remote Server...");
            }
            mRemoteBinder.transact(REQUEST_CODE, data, reply, 0);
            grade = reply.readInt();
            Log.e("ycj", "BinderActivity grade = reply.readInt(): " + grade);
        } catch (RemoteException e) {
            e.printStackTrace();
        }
        return grade;
    }
}
