package ble;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;

import com.example.servicestudy.ServiceMainActivity;
import com.example.viewstudy.ViewMainActivity;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import colour.broadcast.BroadcastActivity;
import colour.kongzhong.com.android_knowledge.R;
import colour.kongzhong.com.android_knowledge.servicetest.MyService;

public class BleDemoActivity extends AppCompatActivity implements View.OnClickListener {
    private static final String TAG = "colour_" + BleDemoActivity.class.getSimpleName();
    private MyService.DownloadBinder downloadBinder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_main);



    }

    @Override
    public void onClick(View v) {
//        if (v.getId() == R.id.activity_fragment_btn) {
//            startActivity(new Intent(this, ServiceMainActivity.class));
//        } else if (v.getId() == R.id.service_btn) {
//            startActivity(new Intent(this, ServiceMainActivity.class));
//        } else if (v.getId() == R.id.broadcast_btn) {
//            startActivity(new Intent(this, ServiceMainActivity.class));
//        } else if (v.getId() == R.id.view_btn) {
//            startActivity(new Intent(this, ViewMainActivity.class));
//        }
    }

}
