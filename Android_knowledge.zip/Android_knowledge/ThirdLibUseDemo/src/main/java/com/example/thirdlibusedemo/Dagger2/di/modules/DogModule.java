package com.example.thirdlibusedemo.Dagger2.di.modules;

import android.util.Log;

import com.example.thirdlibusedemo.Dagger2.di.components.SonComponent;
import com.example.thirdlibusedemo.Dagger2.models.Dog;

import dagger.Module;
import dagger.Provides;

@Module(subcomponents = SonComponent.class)
//@Module
public class DogModule {
    @Provides
    public Dog provideDog() {
        Log.e("ycj", "provideDog to new Dog(11)");
        return new Dog(11);
    }
}
