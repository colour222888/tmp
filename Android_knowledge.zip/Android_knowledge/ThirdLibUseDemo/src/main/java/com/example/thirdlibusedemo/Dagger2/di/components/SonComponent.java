package com.example.thirdlibusedemo.Dagger2.di.components;

import com.example.thirdlibusedemo.Dagger2.di.modules.DogModule;
import com.example.thirdlibusedemo.Dagger2.models.Son;

import dagger.Subcomponent;

@Subcomponent
public interface SonComponent {
    void injectTo(Son son);

    @Subcomponent.Builder
    interface Builder { // SubComponent 必须显式地声明 Subcomponent.Builder，parent Component 需要用 Builder 来创建 SubComponent
        SonComponent build();
    }
}

