package com.example.thirdlibusedemo;

public interface Itask {
    boolean isCancel = false;
    int priority = 1;

    void call();
}
