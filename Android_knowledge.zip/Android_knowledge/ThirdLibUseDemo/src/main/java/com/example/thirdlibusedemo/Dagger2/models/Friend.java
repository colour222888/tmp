package com.example.thirdlibusedemo.Dagger2.models;

import javax.inject.Inject;

public class Friend {
    @Inject
    public Car car;

    public void go() {
        car.go();
    }
}
