package com.example.thirdlibusedemo.javatest;

import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class JavaTest {
    public static void main(String[] arg) {
        new JavaTest().testFan();
//        new JavaTest().testJavaCollection();
//        Person person = new Man();
//        Person agent_person = (Person) Proxy.newProxyInstance(person.getClass().getClassLoader(), Man.class.getInterfaces(), new InvacationHandlerImpl(person));
//        agent_person.eat("apple");
//        agent_person.sayHi();
//
//        System.out.println("hell~~~~~~~!!");
//
//        Ken ken = new Ken();
//        System.out.println("ken.methodB():"+ken.methodB());


        //--- about list
        System.out.println("---------------------------- begin ---------------------------------");
        List<Bean> beanList = new ArrayList<>();
        Bean bean1 = new Bean(1, "ken");
        beanList.add(bean1);
        System.out.println("1 beanList.get(0).name:" + beanList.get(0).name);
        bean1.name = "ken111";
        System.out.println("2 beanList.get(0).name:" + beanList.get(0).name);
        Bean b = beanList.get(0);
        System.out.println("3 beanList.get(0).name:" + b.name);

        beanList.add(new Bean(2, "222"));
        beanList.add(new Bean(3, "333"));
        for (Bean bean : beanList) {
            bean.name = "@@@@";
        }
        System.out.println(" beanList.get(0).name:" + beanList.get(0).name);
        System.out.println(" beanList.get(1).name:" + beanList.get(1).name);
        System.out.println(" beanList.get(2).name:" + beanList.get(2).name);

        System.out.println("---------------------------- end ---------------------------------");

        ArrayList<Bean> list = new ArrayList<>();
        for (int i = 0; i < 5; i++) {
            list.add(new Bean(i, i + ""));
        }
        System.out.println("list 1111:" + list);
        Iterator<Bean> it = list.iterator();
        System.out.println("list 2222");
        while (it.hasNext()) {
            System.out.println("list -----");
            Bean value = it.next();
            value.Number = 99;
        }
        System.out.println("list22:" + list.get(0).Number);
    }

    static class Bean {
        public int Number;
        public String name;

        public Bean(int number, String name) {
            this.Number = number;
            this.name = name;
        }
    }

    private void testJavaCollection() {
        Map<String, String> map1 = new HashMap<>();
        map1.put("1", "a");
        map1.put("2", "b");
        map1.put("3", "c");
        System.out.println("testJavaCollection map1:" + map1);
        map1.put("1", "aaa");
        System.out.println("testJavaCollection map1:" + map1);

        List<String> list1 = new ArrayList<>();
        List<String> list2 = new ArrayList<>();
        List<String> list3 = new ArrayList<>();
        List<String> list4 = new ArrayList<>();

        list2.addAll(list1);

        list3.add("1");
        list3.add("2");
        list3.add("3");
        list4.addAll(list3);
        System.out.println("testJavaCollection list2 isempty:" + list2.isEmpty());
        System.out.println("testJavaCollection list2:" + list2);
        System.out.println("testJavaCollection list4 isempty:" + list4.isEmpty());
        System.out.println("testJavaCollection list4:" + list4);
    }

    public void testFan() {
        Class c1 = null;
        try {
            c1 = Class.forName("com.example.thirdlibusedemo.javatest.JavaTest");
            System.out.println(c1.getName());
        } catch (ClassNotFoundException e) {
        }
        Method[] methods = c1.getDeclaredMethods();
        for (int i = 0; i < methods.length; i++) {
            System.out.println(methods[i]);
        }
    }
}
