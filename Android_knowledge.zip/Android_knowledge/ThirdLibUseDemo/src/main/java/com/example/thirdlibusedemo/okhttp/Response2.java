package com.example.thirdlibusedemo.okhttp;

public class Response2 {

    private String body;

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }

    public String string() {
        return body;
    }

}