package com.example.thirdlibusedemo.Dagger2.models;

import android.util.Log;

import javax.inject.Inject;

public class Father {
    @Inject
    public Dog mDog;

    public void runDog() {
        Log.e("ycj", mDog.mAge + " age dog is run");
    }

}
