package com.example.thirdlibusedemo.retrofit;

import android.util.Log;

public class Car implements IVehical {
    @Override
    public String run(String where) {
        Log.e("ycj", "car is run to " + where);
        return where;
    }

    @Override
    public void jump() {
        Log.e("ycj", "car is jump");
    }
}
