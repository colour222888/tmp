package com.example.thirdlibusedemo.okhttp;

public interface Call2 {

    void enqueue(Callback2 responseCallback);

}
