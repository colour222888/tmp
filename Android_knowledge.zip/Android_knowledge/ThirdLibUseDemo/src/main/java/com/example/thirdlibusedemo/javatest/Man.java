package com.example.thirdlibusedemo.javatest;

import android.util.Log;

public class Man implements Person {
    @Override
    public String eat(String food) {
        System.out.println("Man eat food:" + food);
        return food;
    }

    @Override
    public void sayHi() {
        System.out.println("Man sayHi:");
    }

    public String mehtodA() {
        return "Man class methodA";
    }

    public String methodB() {
        return mehtodA();
    }

}
