package com.example.thirdlibusedemo.Dagger2.di.components;

import com.example.thirdlibusedemo.Dagger2.di.modules.CarModule;
import com.example.thirdlibusedemo.Dagger2.models.Car;
import com.example.thirdlibusedemo.Dagger2.models.Man;

import dagger.Component;
import dagger.Module;

@Component(modules = CarModule.class)
public interface ManComponent {
    void injectTo(Man man);

    Car getCar();

    void fuck(String name);
}
