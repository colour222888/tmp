package com.example.thirdlibusedemo.Dagger2.di.components;

import com.example.thirdlibusedemo.Dagger2.di.modules.CarModule;
import com.example.thirdlibusedemo.Dagger2.models.Friend;

import dagger.Component;

@Component(dependencies = ManComponent.class)
public interface FriendComponent {
    void injectTo(Friend friend);
}
