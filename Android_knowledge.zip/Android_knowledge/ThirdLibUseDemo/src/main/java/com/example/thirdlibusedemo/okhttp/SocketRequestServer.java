package com.example.thirdlibusedemo.okhttp;

public class SocketRequestServer {

    /**
     * 通过Request对象，寻找到域名HOST
     *
     * @param request2
     * @return
     */
    public String getHost(Request2 request2) {
        return null;
    }

}