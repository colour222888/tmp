package com.example.thirdlibusedemo.db.ormlite.bean;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

@DatabaseTable(tableName = "tb_score")
public class Score {
    @DatabaseField(generatedId = true)
    private int id;
    @DatabaseField(columnName = "china")
    private int chinese;
    @DatabaseField(columnName = "math")
    private int math;

    public Score() {
    }

    public Score(int chinese, int math) {
        this.chinese = chinese;
        this.math = math;
    }
}
