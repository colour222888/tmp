package com.example.thirdlibusedemo;

import android.Manifest;
import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.example.thirdlibusedemo.Dagger2.Dagger2DemoAct;
import com.example.thirdlibusedemo.db.ormlite.DBtest;
import com.example.thirdlibusedemo.db.realm.RealmDBtest;
import com.example.thirdlibusedemo.okhttp.OkhttpDemoAct;
import com.example.thirdlibusedemo.retrofit.RetrofitDemoAct;
import com.example.thirdlibusedemo.server.BindService;

public class MainActivity extends Activity {
    Handler mHandler;
    Looper mLooper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
//        authorization();

        /*LinearLayout ly = (LinearLayout) findViewById(R.id.main_act_ly);
        ly.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                return true;
            }
        });

        findViewById(R.id.main_act_btn).setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                return false;
            }
        });
        MyButton myButton = new MyButton(this);
        myButton.setText("my_button");
        ly.addView(myButton);
        myButton.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                return false;
            }
        });
        myButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.e("ycj","my-butn onclick");

                if (myBinder == null){
                    showBindService();
                }else {
//                    Log.e("ycj","myBinder.getMsg():"+myBinder.getMsg());
//                    myBinder.setMsg("myBinder.setMsg: hello");
//                    Log.e("ycj","myBinder.getMsg():"+myBinder.getMsg());
//                    Log.e("ycj","myBinder.getService().getMsg():"+myBinder.getService().getMsg());
//                    myBinder.getService().setMsg("world");
//                    Log.e("ycj","myBinder.getService().getMsg():"+myBinder.getService().getMsg());

                    unBindservic();
                }
            }
        });*/

        /*//ormlite db test
        DBtest.testAddUser(this);
        DBtest.testDeleteUser(this);
        DBtest.testUpdateUser(this);
        DBtest.testAddScore(this);*/

        //realm db test
        RealmDBtest.getInstance(this).createdTest1();
        RealmDBtest.getInstance(this).createUser();
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        Thread.dumpStack();
        return super.dispatchTouchEvent(ev);
    }

    public void OpenOkhttpDemo(View view) {
//        Thread.dumpStack();
        Intent intent = new Intent(this, OkhttpDemoAct.class);
//        Intent intent = new Intent(this, Dagger2DemoAct.class);
//        Intent intent = new Intent(this, RetrofitDemoAct.class);
        startActivity(intent);
    }

    /**
     * 6.0系统以上要动态授权
     */
    private final static int MY_PERMISSION_REQUEST_CODE = 101;

    private void authorization() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            //判断权限
            if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED || checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED) {

                //请求权限
                requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, MY_PERMISSION_REQUEST_CODE);
            } else {
                //6.0系统以下业务操作
            }
        }
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case MY_PERMISSION_REQUEST_CODE:

                boolean isAllGranted = true;

                // 判断是否所有的权限都已经授予了
                for (int grant : grantResults) {
                    if (grant != PackageManager.PERMISSION_GRANTED) {
                        isAllGranted = false;
                        break;
                    }
                }
                //做业务处理或提醒用户开启权限
                if (isAllGranted) {
                    // 如果所有的权限都授予了, 则执行业务处理代码

                } else {
                    // 弹出对话框告诉用户需要权限的原因, 并引导用户去应用权限管理中手动打开权限按钮
                    Toast.makeText(getApplicationContext(), "获取权限失败，可能部分功能无法正常使用，请到应用权限管理中手动打开权限按钮", Toast.LENGTH_SHORT).show();
                }


        }

    }

    private BindService.MyBinder myBinder;
    private ServiceConnection connection;

    private void showBindService() {
        Intent intent = new Intent(this, BindService.class);
        connection = new ServiceConnection() {
            @Override
            public void onServiceConnected(ComponentName name, IBinder service) {
                myBinder = (BindService.MyBinder) service;
            }

            @Override
            public void onServiceDisconnected(ComponentName name) {

            }
        };

        bindService(intent, connection, BIND_AUTO_CREATE);
    }

    private void unBindservic() {
        unbindService(connection);
    }

}
