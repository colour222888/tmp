package com.example.thirdlibusedemo.db.realm.dao;

import io.realm.RealmObject;

public class User2 extends RealmObject {
    public String name;
    public int age;

    @Override
    public String toString() {
        return "User{" +
                "name='" + name + '\'' +
                ", age=" + age +
                '}';
    }
}
