package com.example.thirdlibusedemo.db.ormlite;

import android.content.Context;
import android.util.Log;


import com.example.thirdlibusedemo.db.ormlite.bean.Score;
import com.example.thirdlibusedemo.db.ormlite.bean.User;

import java.sql.SQLException;
import java.util.List;

public class DBtest {
    public static void testAddUser(Context context) {

        User u1 = new User("zhy", "2B青年");
        DatabaseHelper helper = DatabaseHelper.getHelper(context);
        try {
            helper.getUserDao().create(u1);
            u1 = new User("zhy2", "2B青年");
            helper.getUserDao().create(u1);
            u1 = new User("zhy3", "2B青年");
            helper.getUserDao().create(u1);
            u1 = new User("zhy4", "2B青年");
            helper.getUserDao().create(u1);
            u1 = new User("zhy5", "2B青年");
            helper.getUserDao().create(u1);
            u1 = new User("zhy6", "2B青年");
            helper.getUserDao().create(u1);

            testList(context);


        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void testDeleteUser(Context context) {
        DatabaseHelper helper = DatabaseHelper.getHelper(context);
        try {
            helper.getUserDao().deleteById(2);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void testUpdateUser(Context context) {
        DatabaseHelper helper = DatabaseHelper.getHelper(context);
        try {
            User u1 = new User("zhy-android", "2B青年");
            u1.setId(3);
            helper.getUserDao().update(u1);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void testList(Context context) {
        DatabaseHelper helper = DatabaseHelper.getHelper(context);
        try {
            User u1 = new User("zhy-android", "2B青年");
            u1.setId(2);
            List<User> users = helper.getUserDao().queryForAll();
            Log.e("TAG", users.toString());
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void testAddScore(Context context) {
        Score s1 = new Score(1, 11);
        DatabaseHelper helper = DatabaseHelper.getHelper(context);
        try {
            helper.getScoreDao().create(s1);
            s1 = new Score(2, 22);
            helper.getScoreDao().create(s1);
            s1 = new Score(3, 33);
            helper.getScoreDao().create(s1);


            testList(context);


        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
