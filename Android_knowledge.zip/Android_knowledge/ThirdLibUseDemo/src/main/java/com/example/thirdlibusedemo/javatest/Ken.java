package com.example.thirdlibusedemo.javatest;

public class Ken extends Man {
    @Override
    public String mehtodA() {
        return "Ken methodA";
    }
}
