package com.example.thirdlibusedemo.server;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;
import android.support.annotation.Nullable;

public class BindService extends Service {
    private String mMsg = "Bindservice msg";

    public String getMsg() {
        return mMsg;
    }

    public void setMsg(String str) {
        mMsg = str;
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return new MyBinder();
    }

    @Override
    public boolean onUnbind(Intent intent) {
        return super.onUnbind(intent);
    }

    public class MyBinder extends Binder {
        private String mMsg;

        public void setMsg(String msg) {
            mMsg = msg;
        }

        public String getMsg() {
            return mMsg;
        }

        public BindService getService() {
            return BindService.this;
        }
    }

    @Override
    public void onCreate() {
        super.onCreate();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return super.onStartCommand(intent, flags, startId);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }
}
