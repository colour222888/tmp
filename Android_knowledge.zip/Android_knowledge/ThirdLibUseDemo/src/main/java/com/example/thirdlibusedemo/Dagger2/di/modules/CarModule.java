package com.example.thirdlibusedemo.Dagger2.di.modules;

import android.util.Log;

import com.example.thirdlibusedemo.Dagger2.models.Car;

import dagger.Module;
import dagger.Provides;

@Module
public class CarModule {
    @Provides
    public Car provideCar() {
        Log.e("ycj", "provideCar to new Car(defult)");
        return new Car("defult");
    }
}
