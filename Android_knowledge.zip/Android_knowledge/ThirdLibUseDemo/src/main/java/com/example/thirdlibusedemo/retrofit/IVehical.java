package com.example.thirdlibusedemo.retrofit;

public interface IVehical {
    String run(String where);

    void jump();
}
