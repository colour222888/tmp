package com.example.thirdlibusedemo.Dagger2.di.modules;

import com.example.thirdlibusedemo.Dagger2.models.Car;
import com.example.thirdlibusedemo.Dagger2.models.Dog;
import com.example.thirdlibusedemo.Dagger2.models.Person;

import dagger.Module;
import dagger.Provides;

@Module
public class Dagger2DemoActModule {
    private int mDogAge;

    public Dagger2DemoActModule() {
    }

    public Dagger2DemoActModule(int age) {
        mDogAge = age;
    }

    @Provides
    public Person providePerson() {
        Person p = new Person();
        p.mName = "Dagger2DemoActModule.create.person";
        return p;
    }
//
//    @Provides
//    public Car provideCar(){
//        Person p = new Person();
//        p.mName = "Dagger2DemoActModule.create.car";
//        Car car = new Car(p);
//        return car;
//    }
//
//    @Provides
//    public Dog provideDog(){
//        Dog dog = new Dog(mDogAge);
//        return dog;
//    }
}
