package com.example.thirdlibusedemo.retrofit;

import com.google.gson.Gson;
import com.google.gson.TypeAdapter;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;
import java.lang.annotation.Annotation;
import java.lang.reflect.Type;

import okhttp3.ResponseBody;
import retrofit2.Converter;
import retrofit2.Retrofit;

public class MyConverterFactory extends Converter.Factory {
    public static MyConverterFactory create() {
        return create(new Gson());
    }

    private final Gson gson;

    public static MyConverterFactory create(Gson gson) {
        return new MyConverterFactory(gson);
    }

    private MyConverterFactory(Gson gson) {
        if (gson == null) throw new NullPointerException("gson == null");
        this.gson = gson;
    }

    //    @javax.annotation.Nullalbe
    @Override
    public Converter<ResponseBody, ?> responseBodyConverter(Type type, Annotation[] annotations, Retrofit retrofit) {
        TypeAdapter<?> adapter = gson.getAdapter(TypeToken.get(type));
        //判断响应实体类型是否是我们需要特殊处理的特殊类型(此处以String类型)
        if (type == RetrofitDemoAct.Student.class) {
            //创建xxConverter来 进行特殊转换
            return new MyResponseConverter<RetrofitDemoAct.Student>(gson);
        } else {
            //其它类型我们不处理，返回null就行 会交给后面的解析器来解析
            return null;
        }
    }

    private class MyResponseConverter<T> implements Converter<ResponseBody, T> {
        private final Gson gson;

        MyResponseConverter(Gson gson) {
            this.gson = gson;
        }

        @Override
        public T convert(ResponseBody value) throws IOException {
            //在此处进行我们的转换
            String response = value.string();
            RetrofitDemoAct.Student studentBean = gson.fromJson(response, RetrofitDemoAct.Student.class);
//            return (T) response;
            return (T) studentBean;
        }

    }
}
