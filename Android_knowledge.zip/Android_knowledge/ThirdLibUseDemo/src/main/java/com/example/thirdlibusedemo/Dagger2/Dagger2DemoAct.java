package com.example.thirdlibusedemo.Dagger2;

import android.app.Activity;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
//
import com.example.thirdlibusedemo.Dagger2.di.components.DaggerDagger2DemoActComponent;
import com.example.thirdlibusedemo.Dagger2.di.components.DaggerFatherComponent;
import com.example.thirdlibusedemo.Dagger2.di.components.DaggerFriendComponent;
import com.example.thirdlibusedemo.Dagger2.di.components.DaggerManComponent;
import com.example.thirdlibusedemo.Dagger2.di.components.FatherComponent;
import com.example.thirdlibusedemo.Dagger2.di.components.SonComponent;
import com.example.thirdlibusedemo.Dagger2.di.modules.Dagger2DemoActModule;
import com.example.thirdlibusedemo.Dagger2.models.Father;
import com.example.thirdlibusedemo.Dagger2.models.Friend;
import com.example.thirdlibusedemo.Dagger2.models.Man;
import com.example.thirdlibusedemo.Dagger2.models.Person;
import com.example.thirdlibusedemo.Dagger2.models.Son;

import javax.inject.Inject;

public class Dagger2DemoAct extends Activity {
    @Inject
    public Person person;
//    @Inject
//    public Car car;
//    @Inject
//    public Dog dog;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        DaggerDagger2DemoActComponent.builder().build().injectTo(this);
        DaggerDagger2DemoActComponent.builder().dagger2DemoActModule(new Dagger2DemoActModule(55)).build().injectTo(this);
//        AndroidInjection.inject(this);
        if (person != null) {
            Log.e("ycj", "person.mName:" + person.mName);
        }
//        if (car != null){
//            Log.e("ycj","person.mName:"+car.mPerson.mName);
//        }
//        if (dog != null){
//            Log.e("ycj","dog.mAge:"+dog.mAge);
//        }


        Man man = new Man();
        DaggerManComponent.builder().build().injectTo(man);
        man.goWork();
        Friend friend = new Friend();
        DaggerFriendComponent.builder().manComponent(DaggerManComponent.builder().build()).build().injectTo(friend);
        friend.go();

        Father father = new Father();
        DaggerFatherComponent.builder().build().injectTo(father);
        father.runDog();

        FatherComponent fatherCompont = DaggerFatherComponent.builder().build();
        SonComponent sonComponent = fatherCompont.sonComponent().build();
        Son son = new Son();
        sonComponent.injectTo(son);
        son.runDog();
    }
}
