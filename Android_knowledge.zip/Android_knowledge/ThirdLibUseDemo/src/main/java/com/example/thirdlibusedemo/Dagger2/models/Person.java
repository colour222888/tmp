package com.example.thirdlibusedemo.Dagger2.models;

import javax.inject.Inject;

public class Person {
    public String mName;

    @Inject
    public Person() {
        mName = "person";
    }
}
