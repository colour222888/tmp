package com.example.thirdlibusedemo.javatest;

import android.util.Log;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;

public class InvacationHandlerImpl implements InvocationHandler {

    private final Person instance;

    public InvacationHandlerImpl(Person obj) {
        instance = obj;
    }

    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        String methodName = method.getName();
        System.out.println("---------before-------method.getName():" + methodName);
        Object invoke = method.invoke(instance, args);
        System.out.println("---------after-------invoke:" + invoke);

        return invoke;
    }
}