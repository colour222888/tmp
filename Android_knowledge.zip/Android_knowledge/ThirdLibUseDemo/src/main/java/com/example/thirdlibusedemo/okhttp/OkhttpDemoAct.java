package com.example.thirdlibusedemo.okhttp;

import android.app.Activity;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;

import java.io.File;
import java.io.IOException;

import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okio.BufferedSink;

public class OkhttpDemoAct extends Activity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        test();
        /*new Thread(new Runnable() {
            @Override
            public void run() {

                try {
                    //                Log.e("ycj",getRequest("https://wanandroid.com/wxarticle/chapters/json"));

//                    JSONObject jsonObject = new JSONObject();
//                    jsonObject.put("username","123456");
//                    jsonObject.put("password","7890789");
//                    Log.e("ycj", postRequest4json("https://www.wanandroid.com/user/login",jsonObject.toString()));


//                    Log.e("ycj", postRequest4text("https://www.wanandroid.com/user/login","username=123&password=456"));

//                    Log.e("ycj", postRequest4Stream("https://www.wanandroid.com/user/login","username=123&password=456"));

//                    Log.e("ycj", postRequest4keyValue("https://www.wanandroid.com/user/login","username=123&password=456"));

//                    Log.e("ycj", postRequest4Multipart("https://www.wanandroid.com/user/login","username=123&password=456"));

                    Log.e("ycj", postRequest4File("https://www.wanandroid.com/user/login", "username=123&password=456"));

                    *//*FileUtils.getInstance(OkhttpDemoAct.this).copyAssetsToSD("okhttp_test.txt","okhttp");
                    File file = new File("/storage/emulated/0/okhttp");
                    boolean is_directory = file.isDirectory();
                    Log.e("ycj","is_directory:"+is_directory);
                    if (file.isDirectory()){
                        File[] files = file.listFiles();
                        File okhttp_testFile = files[0];
                    }
                    String s = FileUtils.txt2String(file);
                    Log.e("ycj","file content:"+s);*//*
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }).start();*/

    }

    private void test() {
        OkHttpClient2 okHttpClient2 = new OkHttpClient2.Builder().build();
        Request2 request2 = new Request2.Builder().url("https://www.baidu.com/").build();

        Call2 call2 = okHttpClient2.newCall(request2);

        // 执行异步
        call2.enqueue(new Callback2() {
            @Override
            public void onFailure(Call2 call, IOException e) {
                Log.e("ycj","自定义OKHTTP请求失败....");
            }

            @Override
            public void onResponse(Call2 call, Response2 response) throws IOException {
                Log.e("ycj","OKHTTP请求成功.... result:" + response.string());
            }
        });
    }

    /**
     * 1.请求的同步与异步
     * 2.get与post方式
     * 3.post方式的各种形式的请求参数
     * 4.请求配置：例如超时设置，各种设置请求头的api
     * (1.HTTP头部的设置和读取;2.表单提交;3.文件上传;4.使用流的方式发送POST请求;
     * 5.缓存控制;6.Cookies缓存和持久化)
     * 5.断点(续点)下载(上传)
     * 注意：使用同步方式请求需要使用子线程运行
     */


    private OkHttpClient client = new OkHttpClient();
    private MediaType JSON = MediaType.get("application/json; charset=utf-8");
    private MediaType TEXT = MediaType.parse("text/plain");

    private String getRequest(String url) {
        Request request = new Request.Builder()
                .url(url)
                .build();

        try (Response response = client.newCall(request).execute()) {
            if (response.isSuccessful()) {
                return response.body().string();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    private void getRequest(String url, Callback responseCallback) {
        Request request = new Request.Builder()
                .url(url)
                .build();

        client.newCall(request).enqueue(responseCallback);
        client.newCall(request).cancel();
    }

    private String postRequest4json(String url, String json) {
        RequestBody body = RequestBody.create(JSON, json);
        Request request = new Request.Builder()
                .url(url)
                .post(body)
                .build();
        try (Response response = client.newCall(request).execute()) {
            if (response.isSuccessful()) {
                return response.body().string();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    private String postRequest4text(String url, String text) {
        RequestBody body = RequestBody.create(TEXT, text);
        Request request = new Request.Builder()
                .url(url)
                .post(body)
                .build();
        try (Response response = client.newCall(request).execute()) {
            if (response.isSuccessful()) {
                return response.body().string();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    private void postRequest4json(String url, String json, Callback responseCallback) {
        RequestBody body = RequestBody.create(JSON, json);
        Request request = new Request.Builder()
                .url(url)
                .post(body)
                .build();
        client.newCall(request).enqueue(responseCallback);
    }


    //Post方式提交流
    public static final MediaType MEDIA_TYPE_MARKDOWN = MediaType.parse("text/x-markdown; charset=utf-8");

    private String postRequest4Stream(String url, String text) {

        RequestBody requestBody = new RequestBody() {
            //            @javax.annotation.Nullable
            @Override
            public MediaType contentType() {
                return MEDIA_TYPE_MARKDOWN;
            }

            @Override
            public void writeTo(BufferedSink sink) throws IOException {
                sink.writeUtf8("Numbers\n");
                sink.writeUtf8("-------\n");
                for (int i = 2; i <= 11; i++) {
                    sink.writeUtf8((i % 2) + "");
                }
            }
        };
        Request request = new Request.Builder()
                .url(url)
                .post(requestBody)
                .build();
        try (Response response = client.newCall(request).execute()) {
            if (response.isSuccessful()) {
                return response.body().string();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }


    //username=test&password=test
    private String postRequest4keyValue(String url, String json) {
        RequestBody body = new FormBody.Builder()
                .add("username", "test")
                .add("password", "test")
                .build();
        Request request = new Request.Builder()
                .url(url)
                .post(body)
                .build();
        try (Response response = client.newCall(request).execute()) {
            if (response.isSuccessful()) {
                return response.body().string();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    //post file
    private String postRequest4File(String url, String json) {
        File file = new File("/storage/emulated/0/okhttp");
        Request request = new Request.Builder()
                .url(url)
                .post(RequestBody.create(MEDIA_TYPE_MARKDOWN, file))
                .build();
        try (Response response = client.newCall(request).execute()) {
            if (response.isSuccessful()) {
                return response.body().string();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    //Multipart POST 请求
    private String postRequest4Multipart(String url, String json) {
        //InputStream in = MyApplication.this.getClass().getClassLoader().getResourceAsStream("assets/TXUgcSDK.licence");
        RequestBody body = new MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("username", "test")
                .addFormDataPart("password", "test")
                .addFormDataPart("file", "file.txt",
                        RequestBody.create(MediaType.parse("application/octet-stream"),
                                new File("src/test/resources/test.txt")))
                .build();
        Request request = new Request.Builder()
                .url(url)
                .post(body)
                .build();
        try (Response response = client.newCall(request).execute()) {
            if (response.isSuccessful()) {
                return response.body().string();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
}
