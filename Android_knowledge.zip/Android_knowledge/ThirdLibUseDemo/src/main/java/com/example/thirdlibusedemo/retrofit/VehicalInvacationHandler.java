package com.example.thirdlibusedemo.retrofit;

import android.util.Log;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;

/**
 * xuhaixing
 * 2018/7/30 21:38
 **/
public class VehicalInvacationHandler implements InvocationHandler {

    private final IVehical vehical;

    public VehicalInvacationHandler(IVehical vehical) {
        this.vehical = vehical;
    }

    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        String methodName = method.getName();
        Log.e("ycj", "---------before-------method.getName():" + methodName);
//        Log.e("ycj","---------proxy-------:"+proxy);
        Object invoke = method.invoke(vehical, args);
        Log.e("ycj", "---------after-------invoke:" + invoke);

        return invoke;
    }
}