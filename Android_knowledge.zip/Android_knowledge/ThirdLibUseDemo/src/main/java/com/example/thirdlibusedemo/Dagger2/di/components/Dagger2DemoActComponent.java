package com.example.thirdlibusedemo.Dagger2.di.components;

import com.example.thirdlibusedemo.Dagger2.Dagger2DemoAct;
import com.example.thirdlibusedemo.Dagger2.di.modules.Dagger2DemoActModule;

import dagger.Component;

@Component(modules = {Dagger2DemoActModule.class})

public interface Dagger2DemoActComponent {
    void injectTo(Dagger2DemoAct dagger2DemoAct);
}
