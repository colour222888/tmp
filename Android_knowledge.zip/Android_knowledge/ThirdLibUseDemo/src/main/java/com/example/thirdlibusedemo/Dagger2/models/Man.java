package com.example.thirdlibusedemo.Dagger2.models;

import javax.inject.Inject;

public class Man {
    @Inject
    Car car;

    public void goWork() {
        car.go();
    }

}
