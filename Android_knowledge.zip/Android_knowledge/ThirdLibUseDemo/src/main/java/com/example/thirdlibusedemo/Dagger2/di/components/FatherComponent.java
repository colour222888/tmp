package com.example.thirdlibusedemo.Dagger2.di.components;

import com.example.thirdlibusedemo.Dagger2.di.modules.DogModule;
import com.example.thirdlibusedemo.Dagger2.models.Father;

import dagger.Component;

@Component(modules = {DogModule.class})
public interface FatherComponent {
    void injectTo(Father father);

    SonComponent.Builder sonComponent();    // 用来创建 Subcomponent
}
