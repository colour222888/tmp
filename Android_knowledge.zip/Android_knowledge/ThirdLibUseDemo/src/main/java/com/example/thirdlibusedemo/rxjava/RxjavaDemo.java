package com.example.thirdlibusedemo.rxjava;

import android.util.Log;

import org.reactivestreams.Subscriber;

import java.util.Objects;
import java.util.concurrent.TimeUnit;

import io.reactivex.Observable;
import io.reactivex.ObservableEmitter;
import io.reactivex.ObservableOnSubscribe;
import io.reactivex.ObservableSource;
import io.reactivex.Observer;
import io.reactivex.Scheduler;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.BiFunction;
import io.reactivex.functions.Consumer;
import io.reactivex.functions.Function;
import io.reactivex.schedulers.Schedulers;

public class RxjavaDemo {
    public static final String TAG = "ycj";


    /**
     * 基本使用一
     * 观察者(Observer)：监视着被观察者的行为，当被观察者某个状态改变的时候会通知观察者，观察者会执行对应的操作；
     * 被观察者(Observable)：被监视的对象，当某个状态改变的时候会通知观察者；
     * 订阅(subscribe)（或注册）：将观察者和被观察者建立联系。
     * 这里举一个我个常用的例子，点击Button后触发OnClickListener
     * 中的onClick()事件。在这个事件中他们的角色分别如下：
     * 观察者：OnClickListener；
     * 被观察者：Button；
     * 订阅（或注册）：setOnClickListener()。
     * <p>
     * 观察者:它决定事件触发的时候将有怎样的行为。
     * RxJava 观察者的事件回调方法除了普通事件onNext()（相当于onClick()/onEvent()）之外，还定义了两个特殊的事件：onCompleted()和onError()。
     * onCompleted(): 事件队列完结。RxJava 不仅把每个事件单独处理，还会把它们看做一个队列。RxJava 规定，当不会再有新的onNext()发出时，需要触发onCompleted()方法作为标志。
     * onError(): 事件队列异常。在事件处理过程中出异常时，onError()会被触发，同时队列自动终止，不允许再有事件发出。
     * 在一个正确运行的事件序列中,onCompleted()和onError()有且只有一个，并且是事件序列中的最后一个。需要注意的是，onCompleted()
     * 和onError()二者也是互斥的，即在队列中调用了其中一个，就不应该再调用另一个。
     * <p>
     * 被观察者:即被观察者，它决定什么时候触发事件以及触发怎样的事件。可以使用create()、just(T...)、from(T[])或from(Iterable<? extends T>)来创建一个 Observable ，并为它定义事件触发规则。
     * <p>
     * 订阅:创建了Observable和Observer之后，再用subscribe()方法将它们联结起来
     */

    public static void use1() {
        /**
         * 打印结果：
         * onSubscribe : false
         * onNext : value : Cricket
         * onNext : value : Football
         * onComplete
         *
         * onSubscribe : false
         * onNext : value : hello1
         * onNext : value : hello2
         * onError : emitter.onError
         */
        Observable observable = Observable.just("Cricket", "Football");
        Observable observable1 = Observable.create(new ObservableOnSubscribe<String>() {
            @Override
            public void subscribe(ObservableEmitter<String> emitter) throws Exception {
                emitter.onNext("hello1");
                emitter.onNext("hello2");
                emitter.onError(new Throwable("emitter.onError"));
            }
        });

        Observer<String> observer = new Observer<String>() {
            @Override
            public void onSubscribe(Disposable d) {
                Log.e(TAG, " onSubscribe : " + d.isDisposed());
            }

            @Override
            public void onNext(String s) {
                Log.e(TAG, " onNext : value : " + s);
            }

            @Override
            public void onError(Throwable e) {
                Log.e(TAG, " onError : " + e.getMessage());
            }

            @Override
            public void onComplete() {
                Log.e(TAG, " onComplete");
            }
        };

        observable.subscribe(observer);
        observable1.subscribe(observer);


    }

    public static void use2_map() {
        /**
         * 打印：
         * 我从Integer 1 变成了String 1
         * 我从Integer 2 变成了String 2
         * 我从Integer 3 变成了String 3
         */
        Observable.range(1, 3)
                .map(new Function<Integer, String>() {
                    @Override
                    public String apply(Integer integer) throws Exception {
                        return String.format("我从Integer %s 变成了String %s", integer, integer);
                    }
                }).subscribeOn(Schedulers.computation())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Consumer<String>() {
                    @Override
                    public void accept(String s) throws Exception {
                        Log.d("Map", s);
                    }
                });
    }

    public static void use3_flatmap() {
        /**
         * 打印结果：（无序）
         * 第2个数据的第1个转换
         * 第2个数据的第2个转换
         * 第1个数据的第1个转换
         * 第3个数据的第1个转换
         * 第3个数据的第2个转换
         * 第1个数据的第2个转换
         */
        Observable.range(1, 3)
                .flatMap(new Function<Integer, ObservableSource<String>>() {
                    @Override
                    public ObservableSource<String> apply(Integer integer) throws Exception {
                        return Observable.create(new ObservableOnSubscribe<String>() {
                            @Override
                            public void subscribe(ObservableEmitter<String> emitter) throws Exception {
                                emitter.onNext(String.format("第%s个数据的第1个转换", integer));
                                emitter.onNext(String.format("第%s个数据的第2个转换", integer));
                                emitter.onComplete();
                            }
                        }).subscribeOn(Schedulers.newThread());
                    }
                }).subscribe(new Consumer<String>() {
            @Override
            public void accept(String s) throws Exception {
                Log.d("Map", s);
            }
        });
    }

    public static void use3_concatmap() {
        /**
         * 打印结果（有序）
         * 第1个数据的第1个转换
         * 第1个数据的第2个转换
         * 第2个数据的第1个转换
         * 第2个数据的第2个转换
         * 第3个数据的第1个转换
         * 第3个数据的第2个转换
         */
        Observable.range(1, 3)
                .concatMap(new Function<Integer, ObservableSource<String>>() {
                    @Override
                    public ObservableSource<String> apply(Integer integer) throws Exception {
                        return Observable.create(new ObservableOnSubscribe<String>() {
                            @Override
                            public void subscribe(ObservableEmitter<String> emitter) throws Exception {
                                emitter.onNext(String.format("第%s个数据的第1个转换", integer));
                                emitter.onNext(String.format("第%s个数据的第2个转换", integer));
                                emitter.onComplete();
                            }
                        }).subscribeOn(Schedulers.newThread());
                    }
                }).subscribe(new Consumer<String>() {
            @Override
            public void accept(String s) throws Exception {
                Log.d("Map", s);
            }
        });
    }

    public void use4_zip() {
        /**
         * 打印结果：Programmer{age=18, name='WangBen', address='null'}
         */
        Observable.zip(getSs007Age(), getSs007Name(), new BiFunction<Integer, String, Programmer>() {
            @Override
            public Programmer apply(Integer integer, String s) throws Exception {
                return new Programmer(integer, s);
            }
        }).subscribe(new Consumer<Programmer>() {
            @Override
            public void accept(Programmer programmer) throws Exception {
                Log.d("zip", programmer.toString());
            }
        });
    }

    class Programmer {
        private int age;
        private String name;
        private String address;

        public Programmer(int age, String name) {
            this(age, name, null);
        }

        public Programmer(int age, String name, String address) {
            this.age = age;
            this.name = name;
            this.address = address;
        }

        @Override
        public String toString() {
            return "Programmer{" +
                    "age=" + age +
                    ", name='" + name + '\'' +
                    ", address='" + address + '\'' +
                    '}';
        }
    }

    //获取年龄，会耗时3秒
    private static Observable<Integer> getSs007Age() {
        return Observable.just(18).delay(3, TimeUnit.SECONDS);
    }

    private static Observable<String> getSs007Name() {
        return Observable.just("WangBen");
    }

    private static Observable<String> getSs007Address() {
        return Observable.just("TianJin");
    }

    //下面两个为批量获取程序员年龄与姓名的函数
    private static Observable<Integer> getProgrammersAge() {
        return Observable.fromArray(new Integer[]{18, 19});
    }

    private static Observable<String> getProgrammersName() {
        return Observable.fromArray(new String[]{"max", "ben", "leo"});
    }

    //################################################################

    /**
     * Scheduler：线程控制器，可以指定每一段代码在什么样的线程中执行。
     * subscribeOn()：指定subscribe() 所发生的线程，即 Observable.OnSubscribe 被激活时所处的线程。或者叫做事件产生的线程
     * observeOn()：指定Subscriber 所运行在的线程。或者叫做事件消费的线程。
     * <p>
     * Schedulers.immediate()：直接在当前线程运行，相当于不指定线程。这是默认的 Scheduler。
     * Schedulers.newThread()：总是启用新线程，并在新线程执行操作。
     * Schedulers.io()： I/O 操作（读写文件、读写数据库、网络信息交互等）所使用的 Scheduler。行为模式和 newThread() 差不多，区别在于 io() 的内部实现是是用一个无数量上限的线程池，可以重用空闲的线程，因此多数情况下 io() 比 newThread() 更有效率。不要把计算工作放在 io() 中，可以避免创建不必要的线程。
     * Schedulers.computation()：计算所使用的 Scheduler。这个计算指的是 CPU 密集型计算，即不会被 I/O 等操作限制性能的操作，例如图形的计算。这个 Scheduler 使用的固定的线程池，大小为 CPU 核数。不要把 I/O 操作放在 computation() 中，否则 I/O 操作的等待时间会浪费 CPU。
     * AndroidSchedulers.mainThread()：它指定的操作将在 Android 主线程运行。
     */

    public static void use5_scheduler1() {
        /**
         * 打印：
         *use5_scheduler method call thread id : 1
         * ObservableOnSubscribe.subscribe method call thread id : 6944
         * ObservableOnSubscribe.subscribe method call thread id : 1,hello
         */
        Log.e(TAG, " use5_scheduler method call thread id : " + Thread.currentThread().getId());
        Observable.create(new ObservableOnSubscribe<String>() {
            @Override
            public void subscribe(ObservableEmitter<String> emitter) throws Exception {
                Log.e(TAG, " ObservableOnSubscribe.subscribe method call thread id : " + Thread.currentThread().getId());
                emitter.onNext("hello");
            }
        }).subscribeOn(Schedulers.newThread())//指定 subscribe() 发生在新的线程
                .observeOn(AndroidSchedulers.mainThread())// 指定 Subscriber 的回调发生在主线程
                .subscribe(new Consumer<String>() {
                    @Override
                    public void accept(String s) throws Exception {
                        Log.e(TAG, " ObservableOnSubscribe.subscribe method call thread id : " + Thread.currentThread().getId() + "," + s);
                    }
                });
    }

    public static void use5_scheduler2() {
        /**
         * 打印：
         * use5_scheduler method call thread id : 1
         * apply method call thread id : 6966,Hello
         * apply method call thread id : 6966,Wrold
         * accept method call thread id : 1,Hello_modify
         * accept method call thread id : 1,Wrold_modify
         */
        Log.e(TAG, " use5_scheduler method call thread id : " + Thread.currentThread().getId());
        Observable.just("Hello", "Wrold")
                .subscribeOn(Schedulers.newThread())//指定：在新的线程中发起
                .observeOn(Schedulers.io())         //指定：在io线程中处理
                .map(new Function<String, String>() {
                    @Override
                    public String apply(String olde_str) throws Exception {
                        Log.e(TAG, " apply method call thread id : " + Thread.currentThread().getId() + "," + olde_str);
                        return olde_str + "_modify";
                    }
                })
                .observeOn(AndroidSchedulers.mainThread())//指定：在主线程中处理  如果去掉这个observeOn那么会沿用上次的observerOn设置的线程
                .subscribe(new Consumer<String>() {
                    @Override
                    public void accept(String s) throws Exception {
                        Objects.requireNonNull(s);
                        Log.e(TAG, " accept method call thread id : " + Thread.currentThread().getId() + "," + s);
                    }
                });
    }
}














