package com.example.thirdlibusedemo.javatest;

public interface Person {
    String eat(String food);

    void sayHi();
}
