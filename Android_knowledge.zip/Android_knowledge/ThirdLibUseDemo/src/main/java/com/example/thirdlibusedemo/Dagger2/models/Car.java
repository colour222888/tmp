package com.example.thirdlibusedemo.Dagger2.models;

import android.util.Log;

import javax.inject.Inject;

public class Car {
    public String mName;

    public Car(String name) {
        mName = name;
    }

    public void go() {
        Log.e("ycj", mName + " car is going");
    }
}
