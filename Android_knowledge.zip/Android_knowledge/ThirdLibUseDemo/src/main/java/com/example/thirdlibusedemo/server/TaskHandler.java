package com.example.thirdlibusedemo.server;

import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.support.annotation.RequiresApi;

import com.example.thirdlibusedemo.Itask;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TaskHandler {
    private static TaskHandler mInstance;
    private static boolean mIsInit = false;
    private static int sIndext = 1;
    public Handler mHandler;
    private int mCurrentMaxPriority = 1;
    private Map<Integer, Itask> mtaskMap = new HashMap<Integer, Itask>();
    private List<Itask> mReadyExecuteList = new ArrayList<Itask>();

    public static TaskHandler getInstance() {
        if (mInstance == null) {
            synchronized (TaskHandler.class) {
                if (mInstance == null) {
                    mInstance = new TaskHandler();
                }
            }
        }
        return mInstance;
    }

    public static void init() {
        TaskHandler.getInstance();//防止post时，handler为null
        mIsInit = true;
    }

    public static void destory() {
        if (!mIsInit) {
            return;
        }
        TaskHandler.getInstance().mHandler.getLooper().quit();
    }

    private TaskHandler() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                Looper.prepare();
                mHandler = new Handler(Looper.myLooper()) {
                    @RequiresApi(api = Build.VERSION_CODES.N)
                    @Override
                    public void handleMessage(Message msg) {
                        Itask task = mtaskMap.get(msg.what);
                        if (task.priority < mCurrentMaxPriority) {
                            mReadyExecuteList.add(task);
                            mtaskMap.remove(msg.what);
                            mReadyExecuteList.sort(new Comparator<Itask>() {
                                @Override
                                public int compare(Itask o1, Itask o2) {
                                    return o1.priority - o2.priority;
                                }
                            });
                        } else {
                            if (!task.isCancel) {
                                task.call();
                            }
                            executeOtherTask();
                            reSetCurrentMaxPriority();
                        }
                    }
                };
                Looper.loop();
            }
        }).start();
    }

    public void send(Itask task) {
        if (mHandler == null) {

        } else {
            Message msg = Message.obtain();
            msg.what = sIndext;
            mtaskMap.put(sIndext, task);
            sIndext++;
            if (task.priority > mCurrentMaxPriority) {
                mCurrentMaxPriority = task.priority;
            }
            mHandler.sendMessage(msg);
        }
    }

    private void executeOtherTask() {
        for (Itask task : mReadyExecuteList) {
            if (!task.isCancel) {
                task.call();
            }
        }
    }

    private void reSetCurrentMaxPriority() {
        mCurrentMaxPriority = 1;
        for (Itask task : mtaskMap.values()) {
            if (task.priority > mCurrentMaxPriority) {
                mCurrentMaxPriority = task.priority;
            }
        }
    }
}
