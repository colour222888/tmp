package com.example.thirdlibusedemo.Dagger2.models;


public class Dog {

    public int mAge;

    public Dog(int age) {
        mAge = age;
    }
}
