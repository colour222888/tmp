package com.example.thirdlibusedemo.retrofit;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

import com.example.thirdlibusedemo.R;
import com.example.thirdlibusedemo.rxjava.RxjavaDemo;
import com.google.gson.Gson;

import org.json.JSONObject;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import io.reactivex.Observable;
import io.reactivex.functions.Action;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;
import okhttp3.Headers;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.GET;

public class RetrofitDemoAct extends Activity {
    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        int a = 1;
        return super.dispatchTouchEvent(ev);
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Button button = new Button(this);
        button.setText("retrofit get request");
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Looper.myLooper();
//                Handler h;
//                Map map = new HashMap();
//
//                retrofitUseShow_gson();

//                try {
////                    Gson gson = new Gson();
////                    Student student = new Student();
////                    student.setStudentId("33");student.setStudentName("peter");
////                    gson.toJson(student);
//
//                    JSONObject jsonObject = new JSONObject();
//                    jsonObject.put("StudentId","22");jsonObject.put("StudentName","ken");
//                    Gson gson = new Gson();
//                    Student gson2student = gson.fromJson(jsonObject.toString(),Student.class);
//                    Log.e("ycj","gson2student:"+gson2student);
//                }catch (Exception e){
//
//                }


//                new RxjavaDemo().use4_zip();
//                RxjavaDemo.use5_scheduler2();
                //test
//                String str1 = "abc".replace('a','A');
//                String str2 = "htt:\/\/";

                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        rxjava2retrofit();
                    }
                }).start();
            }
        });
        setContentView(button);

    }

    private static final String WAN_URL = "https://wanandroid.com/wxarticle/chapters/json/";
    private static final String TEST_URL = "https://androidtutorialpoint.com/";

    private void retrofitUseShow_ResponseBody() {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(TEST_URL)
                .build();

        BlogService service = retrofit.create(BlogService.class);

        Call<ResponseBody> call = service.getBlog();
        // 用法和OkHttp的call如出一辙,
        // 不同的是如果是Android系统回调方法执行在主线程
        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {

                try {
                    Log.e("ycj", "response.body().string():" + response.body().string());
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                t.printStackTrace();
            }
        });
    }

    private void retrofitUseShow_gson() {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(TEST_URL)
                .addConverterFactory(GsonConverterFactory.create())
//                .addConverterFactory(MyConverterFactory.create())
                .build();

        BlogServiceGson service = retrofit.create(BlogServiceGson.class);

        Call<Student> call = service.getBlog();
        // 用法和OkHttp的call如出一辙,
        // 不同的是如果是Android系统回调方法执行在主线程
        call.enqueue(new Callback<Student>() {
            @Override
            public void onResponse(Call<Student> call, Response<Student> response) {

                try {
                    Headers headers = response.headers();


                    Log.e("ycj", "response.body().string():" + response.body().toString());
//                    System.out.println(response.body().string());
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(Call<Student> call, Throwable t) {
                t.printStackTrace();
            }
        });
    }

    public interface BlogService {
//        @GET("blog/{id}")// baseurl/blog/id
//        Call<ResponseBody> getBlog(@Path("id") int id);

        //        @GET(".")//不带参数
        @GET("api/RetrofitAndroidObjectResponse")
        Call<ResponseBody> getBlog();
    }

    public interface BlogServiceGson {
//        @GET("blog/{id}")// baseurl/blog/id
//        Call<ResponseBody> getBlog(@Path("id") int id);

        //        @GET(".")//不带参数
        @GET("api/RetrofitAndroidObjectResponse")
        Call<Student> getBlog();
    }

    public interface BlogServiceRxjava {
        @GET("api/RetrofitAndroidObjectResponse")
        Observable<Student> getBlog();
    }

//    public interface APIService {
//        @FormUrlEncoded
//        @POST("login")
//        Flowable<HttpResult<UserInfoData>> login(@FieldMa Map<String,  String> map);//登陆
//    }


    //################################################
    class Student {
        String StudentId;
        String StudentName;
//        String StudentMarks;

        public String getStudentId() {
            return StudentId;
        }

        public void setStudentId(String studentId) {
            StudentId = studentId;
        }

        public String getStudentName() {
            return StudentName;
        }

        public void setStudentName(String studentName) {
            StudentName = studentName;
        }

//        public String getStudentMarks() {
//            return StudentMarks;
//        }
//
//        public void setStudentMarks(String studentMarks) {
//            StudentMarks = studentMarks;
//        }

        @Override
        public String toString() {
            return "Student{" +
                    "StudentId='" + StudentId + '\'' +
                    ", StudentName='" + StudentName + '\'' +
//                    ", StudentMarks='" + StudentMarks + '\'' +
                    '}';
        }
    }

    //Rxjava retrofit
    private void rxjava2retrofit() {
        try {
            Retrofit retrofit = new Retrofit.Builder()
                    .baseUrl(TEST_URL)
                    .addConverterFactory(GsonConverterFactory.create())
                    .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                    .build();
            retrofit.create(BlogServiceRxjava.class).getBlog()
//                .subscribeOn(Schedulers.newThread())
//                    .observeOn(Schedulers.io())
                    .subscribe(new Consumer<Student>() {
                        @Override
                        public void accept(Student student) throws Exception {
                            String studentId = student.getStudentId();
                            String studentName = student.getStudentName();
                        }
                    }, new Consumer<Throwable>() {
                        @Override
                        public void accept(Throwable throwable) throws Exception {

                        }
                    }, new Action() {
                        @Override
                        public void run() throws Exception {

                        }
                    });
        } catch (Exception e) {
            String message = e.getMessage();
            Log.e("ycj", e.getMessage());
        }
    }
}
